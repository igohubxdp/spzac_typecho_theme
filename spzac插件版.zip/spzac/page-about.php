<?php 
header('Content-Type: text/html;charset=utf-8');
$cid=$_POST["id"];
$genum=$_POST["genum"];
if($cid!=''){  
$this->widget('Widget_Archive@indexxiu', 'pageSize=1&type=post', 'cid='.$cid)->to($ji); 
$vtit=$ji->title;  
$vcon=$ji->content;
$aaa =  array('vcon'=>$vcon,'vtit'=>$vtit);
$bbb  =json_encode($aaa);
echo $bbb;  
exit();
} 
else{
 if($genum!=''){  
   //
    
$vuser=get_logins($genum); 
$aaa =  array('vuser'=>$vuser);
$bbb  =json_encode($aaa);
echo $bbb;  
exit();
   //
 }
}
?>


<?php

/**
* 关于我们
*
* @package custom
*/

if (!defined('__TYPECHO_ROOT_DIR__')) exit;
 $this->need('header.php');
 ?>

	<!-- main content -->
	<main class="main main--breadcrumb">
		<!-- breadcrumb -->
		<?php $this->need('assets/post - link.php'); ?>
		<!-- end breadcrumb -->

		<div class="container">
			<div class="row">
				<div class="col-12 col-md-7 col-lg-8 col-xl-9">
					<!-- post -->
<?php if ($this->options->txtadimg): ?>
<div class="post post-ad"><?php $this->options->txtadimg(); ?></div>
<?php endif; ?>
					<div class="post c_con">                       

						<div class="post__head c_head">
                          
                          <h2 class="post__title"><?php $this->title(); ?></h2>

						</div>
           

                       
 <?php if ($this->is('attachment')) : ?><h2 class="post__title">附件页面禁止访问哦</h2>
					
                 
                  <?php else: ?>
                      					
   

						<div class="post__description conts">
                <?php if ($this->options->cdnopen == '0'):?>
				<?php $str=$this->content; echo costcn($this->cid,$this->remember('mail',true),$str,$this->user->hasLogin()); ?>
				<?php else : ?>
				<?php $str = str_replace($this->options->cdnurla,$this->options->cdnurlb,$this->content); echo costcn($this->cid,$this->remember('mail',true),$str,$this->user->hasLogin());  ?>	
				<?php endif; ?> 
                 
						</div>
                       <?php endif; ?>    
                       
                      
                       

				        <div class="Copyrightnew">文章由官网发布，如若转载，请注明出处：<?php $this->permalink() ?></div>   
                      
                        <div class="downmoi"></div>

						<div class="post__tags">
							<?php $this->tags(' ', true, ''); ?>
						</div>

						<div class="post__stats">
							<div>
								
								<a class="post__comments" data-toggle="collapse" href="#collapse3" role="button" aria-expanded="false" aria-controls="collapse3"><i class="icon ion-ios-text"></i> <span><?php $this->commentsNum('0 评论', '1 条评论', '%d 条评论'); ?></span></a>
							</div>

							<div class="post__views">
								<i class="icon ion-ios-eye"></i> <span><?php Postviews($this); ?></span>
							</div>
						</div>

					</div>
					<!-- end post -->
<?php if ($this->options->txtaddown): ?>
<div class="post post-ad"><?php $this->options->txtaddown(); ?></div>
<?php endif; ?>
					<!-- comments --> 
					<h3 class="main__title"><?php _e('发表评论'); ?></h3>
                    <?php $this->need('comments.php'); ?>
					<!-- end comments -->

					<?php $this->need('assets/post - more.php'); ?>

				</div>

				
              
                 <?php if ($this->fields->down||$this->fields->downb||$this->fields->downc): ?>
				 <?php $this->need('down - sider.php'); ?>
                 <?php else: ?>
                 <?php $this->need('info - sider.php'); ?>
                 <?php endif; ?>

			</div>
		</div>
	</main>
	<!-- end main content -->

	<!-- footer -->
	<?php $this->need('footer.php'); ?>
	<!-- end footer -->

