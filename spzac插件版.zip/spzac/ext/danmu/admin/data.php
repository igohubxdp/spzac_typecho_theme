<?php
 $yzm =  array (
  'danmuon' => 'on',
  'color' => '#00a1d6',
  'logo' => 'https://i.0f1.cn/tlogo.png',
  'waittime' => '1331',
  'sendtime' => '1',
  'dmrule' => '../dmku/dm_rule.html',
  'pbgjz' => '草,操,妈,逼,滚,网址,网站,支付宝,企,关注,wx,微信,qq,QQ',
  'ads' => 
  array (
    'state' => 'on',
    'set' => 
    array (
      'state' => '2',
      'group' => '2',
      'pic' => 
      array (
        'time' => '3',
        'img' => 'https://i.0f1.cn/2776606.png',
        'link' => '#',
      ),
      'vod' => 
      array (
        'url' => 'https://xiao.dpaoz.com/2020831.mp4',
        'link' => '11',
      ),
    ),
    'pause' => 
    array (
      'state' => 'on',
      'pic' => 'https://i.0f1.cn/2587136.png',
      'link' => 'https://www.dpaoz.com/',
    ),
  ),
);
?>