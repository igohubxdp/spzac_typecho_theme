<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;

require_once("lib/config - member.php");
require_once("lib/config - payview.php");


function themeConfig($form) {
$db = Typecho_Db::get();
$sjdq=$db->fetchRow($db->select()->from ('table.options')->where ('name = ?', 'theme:spzac'));
$ysj = $sjdq['value'];
if(isset($_POST['type']))
{ 
if($_POST["type"]=="备份模板数据"){
if($db->fetchRow($db->select()->from ('table.options')->where ('name = ?', 'theme:spzacbf'))){
$update = $db->update('table.options')->rows(array('value'=>$ysj))->where('name = ?', 'theme:spzacbf');
$updateRows= $db->query($update);
echo '<div class="tongzhi">备份已更新，请等待自动刷新！如果等不到请点击';
?>    
<a href="<?php Helper::options()->adminUrl('options-theme.php'); ?>">这里</a></div>
<script language="JavaScript">window.setTimeout("location=\'<?php Helper::options()->adminUrl('options-theme.php'); ?>\'", 2500);</script>
<?php
}else{
if($ysj){
     $insert = $db->insert('table.options')
    ->rows(array('name' => 'theme:spzacbf','user' => '0','value' => $ysj));
     $insertId = $db->query($insert);
echo '<div class="tongzhi">备份完成，请等待自动刷新！如果等不到请点击';
?>    
<a href="<?php Helper::options()->adminUrl('options-theme.php'); ?>">这里</a></div>
<script language="JavaScript">window.setTimeout("location=\'<?php Helper::options()->adminUrl('options-theme.php'); ?>\'", 2500);</script>
<?php
}
}
}
if($_POST["type"]=="还原模板数据"){
if($db->fetchRow($db->select()->from ('table.options')->where ('name = ?', 'theme:spzacbf'))){
$sjdub=$db->fetchRow($db->select()->from ('table.options')->where ('name = ?', 'theme:spzacbf'));
$bsj = $sjdub['value'];
$update = $db->update('table.options')->rows(array('value'=>$bsj))->where('name = ?', 'theme:spzac');
$updateRows= $db->query($update);
echo '<div class="tongzhi">检测到模板备份数据，恢复完成，请等待自动刷新！如果等不到请点击';
?>    
<a href="<?php Helper::options()->adminUrl('options-theme.php'); ?>">这里</a></div>
<script language="JavaScript">window.setTimeout("location=\'<?php Helper::options()->adminUrl('options-theme.php'); ?>\'", 2000);</script>
<?php
}else{
echo '<div class="tongzhi">没有模板备份数据，恢复不了哦！</div>';
}
}
if($_POST["type"]=="删除备份数据"){
if($db->fetchRow($db->select()->from ('table.options')->where ('name = ?', 'theme:spzacbf'))){
$delete = $db->delete('table.options')->where ('name = ?', 'theme:spzacbf');
$deletedRows = $db->query($delete);
echo '<div class="tongzhi">删除成功，请等待自动刷新，如果等不到请点击';
?>    
<a href="<?php Helper::options()->adminUrl('options-theme.php'); ?>">这里</a></div>
<script language="JavaScript">window.setTimeout("location=\'<?php Helper::options()->adminUrl('options-theme.php'); ?>\'", 2500);</script>
<?php
}else{
echo '<div class="tongzhi">不用删了！备份不存在！！！</div>';
}
}
  
  if($_POST["type"]=="生成地图"){

 getxml();
        echo '<div class="tongzhi">更新成功，请等待自动刷新，如果等不到请点击';
 ?><a href="<?php Helper::options()->adminUrl('options-theme.php'); ?>">这里</a></div><script language="JavaScript">window.setTimeout("location=\'<?php Helper::options()->adminUrl('options-theme.php'); ?>\'", 1000);</script><?php 
} 
  
  
}
 
  
    /**
	 *  设置样式+面板
	 */	 
	echo '<link rel="stylesheet" href="/usr/themes/spzac/assets/css/setting.spzac.css"><link rel="stylesheet" href="/usr/themes/spzac/fonts/iconfont.css"> <link href="https://fonts.googleapis.com/css?family=Noto+Sans+SC:300|Noto+Serif+SC:300&display=swap" rel="stylesheet"><script src="//cdn.staticfile.org/jquery/3.4.1/jquery.min.js"></script><script src="/usr/themes/spzac/assets/css/setjs.js"></script>';
	echo '<div class="miracles-pannel">
	<h1>Spzac 正式版设置面板</h1>
	<p>用于作品展示、资源下载，行业垂直性网站、个人博客，简洁大气、优化SEO、多功能配置。</p>
    <p>官网下载地址（版本更新）：<a href="https://www.dpaoz.com/204">https://www.dpaoz.com/204</a></p>
    <hr><p>提交sitemap可以向搜索提交网站的sitemap文件，帮助spider更好的抓取您的网站。</p>';
    $index = Helper::options()->siteUrl;
    echo "<p>sitemap.xml地图：<a href='".$index."sitemap.xml' target='_blank'>".$index."sitemap.xml</a> <a href='https://ziyuan.baidu.com/linksubmit'>(地图提交)</a><p>";
    $apikeypage = Helper::options()->apikeypage;
    $apikey = Helper::options()->apikey;
   
    echo '<hr>   
   	  <form class="protected" action="?MiraclesBackup" method="post">
        <input type="submit" name="type" class="miracles-backup-button backup" value="备份模板数据" />&nbsp;&nbsp;
	    <input type="submit" name="type" class="miracles-backup-button recover" value="还原模板数据" />&nbsp;&nbsp;
	    <input type="submit" name="type" class="miracles-backup-button delete" value="删除备份数据" />
        <input type="submit" name="type" class="miracles-backup-button onemap" value="生成地图" />
	  </form>      
	</div>';
  
  
    
  
    $logoUrl = new Typecho_Widget_Helper_Form_Element_Text('logoUrl', NULL, NULL, _t('<h2 id="div-1">常规设置 Info</h2><hr>站点LOGO地址'), _t('在这里填入一个图片URL地址, 以在网站标题前加上一个logo,留空则会显示网站文字标题'));
    $form->addInput($logoUrl);
    
    $iyuukey = new Typecho_Widget_Helper_Form_Element_Text('iyuukey', NULL, NULL, _t('爱语飞飞key'), _t('用以评论信息微信推送'));
    $form->addInput($iyuukey);
    
    
  
    $blogme = new Typecho_Widget_Helper_Form_Element_Text('blogme', NULL, NULL, _t('博主头像图片'), _t('在这里填入你的头像图片地址，http://www.yourblog.com/image.png,支持 https:// 或 //'));
    $form->addInput($blogme);

	$favicon = new Typecho_Widget_Helper_Form_Element_Text('favicon', NULL, NULL, _t('favicon地址'), _t('一般为http://www.yourblog.com/image.png,支持 https:// 或 //,留空则不设置favicon'));
    $form->addInput($favicon);  
  
 	$webhdp = new Typecho_Widget_Helper_Form_Element_Textarea('webhdp', NULL, NULL, _t('幻灯片设置'), _t(''));
    $form->addInput($webhdp); 
   
  
    $tipid = new Typecho_Widget_Helper_Form_Element_Text('tipid', NULL, NULL, _t('公告文章'), _t('输入文章的id号'));
    $form->addInput($tipid);  


	$aboutme = new Typecho_Widget_Helper_Form_Element_Text('aboutme', NULL, NULL, _t('<h2 id="div-2">用户中心 Uer</h2><hr>关于我们'), _t('这里需要填页面的缩略名'));
    $form->addInput($aboutme); 
  
    $signup = new Typecho_Widget_Helper_Form_Element_Text('signup', NULL, NULL, _t('注册地址'), _t('开启后，填自定义的注册地址，不开启用户中心，则不填，默认插件地址'));
    $form->addInput($signup); 
  
    $signin = new Typecho_Widget_Helper_Form_Element_Text('signin', NULL, NULL, _t('登录地址'), _t('开启后，填自定义的登录地址，不开启用户中心，则不填，默认插件地址'));
    $form->addInput($signin);
    
    $qqget = new Typecho_Widget_Helper_Form_Element_Select('qqget',array('0'=>'不开启','1'=>'开启'),'0','是否开启一键qq评论','默认是不开启，正常输入邮箱，昵称');
    $form->addInput($qqget);

	$webgong = new Typecho_Widget_Helper_Form_Element_Textarea('webgong', NULL, NULL, _t('官网公告'), _t('官网公告信息'));
    $form->addInput($webgong);

    $imghdp = new Typecho_Widget_Helper_Form_Element_Text('imghdp', NULL, NULL, _t('<hr><h2  id="div-3">首页设置 Index</h2><hr>首页推荐位置'), _t(''));
    $form->addInput($imghdp);

    $nolist = new Typecho_Widget_Helper_Form_Element_Text('nolist', NULL, NULL, _t('首页不显示某分类'), _t('仅用在首页，首页不显示某分类，填入<b style="color: red;">缩略名</b>'));
    $form->addInput($nolist); 
  
    $inlist = new Typecho_Widget_Helper_Form_Element_Text('inlist', NULL, NULL, _t('首页列表栏目ID'), _t('首页列表栏目ID'));
    $form->addInput($inlist); 
  
    $sidelist = new Typecho_Widget_Helper_Form_Element_Text('sidelist', NULL, NULL, _t('边栏分类ID'), _t('指定边栏显示的ID'));
    $form->addInput($sidelist); 

	$zhiduid = new Typecho_Widget_Helper_Form_Element_Text('zhiduid', NULL, NULL, _t('置顶文章ID'), _t('在这里填入置顶文章ID,输入1~2个文章ID,设置太多,会影响美观，推荐1,2个最为合适'));
    $form->addInput($zhiduid);

    $adimg = new Typecho_Widget_Helper_Form_Element_Text('adimg', NULL, NULL, _t('<h2 id="div-4">广告设置 Advert</h2><hr>首页列表广告'), _t('第2个位置,在这里填入你广告图片链接代码：&lt;a rel="nofollow" target="_blank" href=""&gt; &lt;img src="图片链接"&gt;  &lt;/a&gt;'));
    $form->addInput($adimg);
  
    $adimgb = new Typecho_Widget_Helper_Form_Element_Text('adimgb', NULL, NULL, _t('首页列表广告'), _t('第8个位置，在这里填入你广告图片链接代码：&lt;a rel="nofollow" target="_blank" href=""&gt; &lt;img src="图片链接"&gt;  &lt;/a&gt;'));
    $form->addInput($adimgb);
  
    $adside = new Typecho_Widget_Helper_Form_Element_Text('adside', NULL, NULL, _t('边栏广告'), _t('边栏广告，在这里填入你广告图片链接代码：&lt;a rel="nofollow" target="_blank" href=""&gt; &lt;img src="图片链接"&gt;  &lt;/a&gt;'));
    $form->addInput($adside);

	$txtadimg = new Typecho_Widget_Helper_Form_Element_Text('txtadimg', NULL, NULL, _t('文章上方广告'), _t('在这里填入你广告图片链接代码：&lt;a rel="nofollow" target="_blank" href=""&gt; &lt;img src="图片链接"&gt;  &lt;/a&gt;'));
    $form->addInput($txtadimg);

	$txtaddown = new Typecho_Widget_Helper_Form_Element_Text('txtaddown', NULL, NULL, _t('文章下方底部广告'), _t('在这里填入你广告图片链接代码：&lt;a rel="nofollow" target="_blank" href=""&gt; &lt;img src="图片链接"&gt;  &lt;/a&gt;'));
    $form->addInput($txtaddown);
  
    $vipbuyad = new Typecho_Widget_Helper_Form_Element_Text('vipbuyad', NULL, NULL, _t('vip会员广告'), _t('在这里填入你广告图片链接代码：&lt;a rel="nofollow" target="_blank" href=""&gt; &lt;img src="图片链接"&gt;  &lt;/a&gt;'));
    $form->addInput($vipbuyad);

	$webcss = new Typecho_Widget_Helper_Form_Element_Textarea('webcss', NULL, NULL, _t('<h2 id="div-5">风格样式 Style</h2><hr>自定义CSS'), _t('自定义样式,内置nexzhu和webmo字体，切换可添加<b style="color: red;">body {font-family: nexzhu!important;}</b> 或者 <b style="color: red;">body {font-family: webmo!important;}</b>'));
    $form->addInput($webcss);

	$tophtml = new Typecho_Widget_Helper_Form_Element_Textarea('tophtml', NULL, NULL, _t('页头代码'), _t('添加在页面</head>前,比如：站长平台HTML验证代码,谷歌分析代码'));
    $form->addInput($tophtml);

	$foothtml = new Typecho_Widget_Helper_Form_Element_Textarea('foothtml', NULL, NULL, _t('页脚代码'), _t('添加在页面</body>前,比如：客服工具等js代码，注意 统计代码不在这里填！！'));
    $form->addInput($foothtml);
  
	$footnav = new Typecho_Widget_Helper_Form_Element_Textarea('footnav', NULL, NULL, _t('<h2 id="div-6">页脚设置 Foot</h2><hr>页脚版权设置'), _t('页脚版权/备案信息，比如：版权所有 本站内容未经书面许可,禁止一切形式的转载。粤ICP备17062710号-1. All rights reserved.'));
    $form->addInput($footnav);
	$footlogo = new Typecho_Widget_Helper_Form_Element_Text('footlogo', NULL, NULL, _t('页脚LOGO图片地址'), _t('在这里填入你的页脚LOGO图片地址,http://www.yourblog.com/image.png,支持 https:// 或 //'));
    $form->addInput($footlogo);

    $zztj = new Typecho_Widget_Helper_Form_Element_Text('zztj', NULL, NULL, _t('网站统计代码'), _t('在这里填入你的网站统计代码,这个可以到百度统计或者cnzz上申请。'));
    $form->addInput($zztj);	  
	$themecompress = new Typecho_Widget_Helper_Form_Element_Select('themecompress',array('0'=>'不开启','1'=>'开启'),'0','HTML压缩功能','是否开启HTML压缩功能,缩减页面代码');
    $form->addInput($themecompress);  
  
}

//后台编辑器添加功能
function themeFields($layout) {	
  
    $img = new Typecho_Widget_Helper_Form_Element_Text('img', NULL, NULL, _t('封面图'), _t('在这里填入一个图片 URL 地址, 以添加显示本文的缩略图，留空则显示默认缩略图'));
    $img->input->setAttribute('class', 'w-100 setfb');
    $layout->addItem($img);
    
    $videourl = new Typecho_Widget_Helper_Form_Element_Text('videourl', NULL, NULL, _t('视频链接'), _t('在这里填入一个视频 URL 地址, 以添加显示视频，留空则没有'));
    $videourl->input->setAttribute('class', 'w-100 setfb');
    $layout->addItem($videourl);

	$down = new Typecho_Widget_Helper_Form_Element_Text('down', NULL, NULL, _t('免费下载'), _t('无需注册，也可以直接下载'));
    $down->input->setAttribute('class', 'w-100 setfb');
    $layout->addItem($down); 
  
    $downb = new Typecho_Widget_Helper_Form_Element_Text('downb', NULL, NULL, _t('注册下载'), _t('需要注册登录后才能下载'));
    $downb->input->setAttribute('class', 'w-100 setfb');
    $layout->addItem($downb); 
    
    $sidedown = new Typecho_Widget_Helper_Form_Element_Select('sidedown',array('1'=>'开启','0'=>'关闭'),'0','关闭边栏下载','默认是开启，开启状态下编辑器无需设置TePass短代码格式');
    $sidedown->input->setAttribute('class', 'w-100 setfb no_set');
    $layout->addItem($sidedown);
  
    $payview = new Typecho_Widget_Helper_Form_Element_Textarea('payview', NULL, NULL, _t('列表阅读文章'), _t('填入文章id，则会自动开启,格式：<br>跳转：1|文章id<br>加载：0|文章id'));
    $payview->input->setAttribute('class', 'w-100 setfb');
    $layout->addItem($payview);
 
    //$inshare = new Typecho_Widget_Helper_Form_Element_Text('inshare', NULL, NULL, _t('权益合伙人'), _t('填入用户id则会默认合伙人'));
    //$inshare->input->setAttribute('class', 'w-100 setfb');
    //$layout->addItem($inshare);
    

  
}

function themeInit($archive) {
//设置栏目数量的地方
if ($archive->is('category', 'pro')) {
$archive->parameter->pageSize = 36; // 自定义条数
}
  if ($archive->is('category', 'down')) {
$archive->parameter->pageSize = 32; // 自定义条数
}
}

/**输出作者评论总数，可以指定*/
function commentnum($id){
    $db = Typecho_Db::get();
    $commentnum=$db->fetchRow($db->select(array('COUNT(authorId)'=>'commentnum'))->from ('table.comments')->where ('table.comments.authorId=?',$id)->where('table.comments.type=?', 'comment'));
    $commentnum = $commentnum['commentnum'];    
	echo '评论 '.$commentnum.' 次';
}

// 会员页判断是否会员id，会员页面需要
function userok($id){
$db = Typecho_Db::get();
$userinfo=$db->fetchRow($db->select()->from ('table.users')->where ('table.users.uid=?',$id));
return $userinfo;
}

// 查询会员是否购买 用户 or 文章 --疑似出现问题
function paypostok($id,$cid){
$db = Typecho_Db::get();
$payinfo=$db->fetchRow($db->select()->from ('table.tepass_fees')->where ('fee_uid=?',$id)->where ('fee_cid=?',$cid));
return $payinfo;
}

// 判断文章是否存在付费订单 
function onpayost($id){
	$i=0;
    $db=Typecho_Db::get();
    $payost = $db->fetchRow($db->select('post_price')->from('table.tepass_posts')->where('post_id = ?',$id));
	if($payost[post_price]!=null) {
	$i=1;	
	}
	return $i;
}

// 查询会员期限 
function ueretime($id){
    $db = Typecho_Db::get();
    $userinfo=$db->fetchRow($db->select()->from ('table.tepass_vips')->where ('vip_uid=?',$id));
    if($userinfo['vip_status']!=null){
    $endtime = $userinfo['vip_status'];
    if($endtime==1){
        return '月会员';
    }
    if($endtime==12){
        return '年会员';
    }
     if($endtime==60){
        return '终身会员';
    }
    }
    return '非会员';
}


// 输出付费内容的用户头像 
function clusr($cid){
    $db=Typecho_Db::get();
    $clusrinfo = $db->fetchAll($db->select()->from('table.tepass_fees')->where('fee_cid = ?',$cid)->where('fee_status=?', '1')->order('fee_intime',Typecho_Db::SORT_DESC));
	if($clusrinfo){
      $i=0;
      foreach($clusrinfo as $clusrinfo){  
      $usrinfo = $db->fetchRow($db->select()->from('table.users')->where('uid = ?',$clusrinfo['fee_uid']));
      $usrmail =  $usrinfo['mail'];
      $usrname =  $usrinfo['screenName'];
      $imgUrl = getGravatar($usrmail);
        
      if($i<5){          
      $str = $str.'<img title="'.$usrname.'已购买" src="'.$imgUrl.'">'; //不再继续生成头像，但是数量继续统计
      }
      $i=$i+1;
        
      }//循环结束
      
            
      if($i>=5){
         $str = $str.'<div class="recommended-designer_more js-plus-n">+'.$i.'</div>';
      }
      
      echo $str;
      
    }
}



// 判断下单数 
function payfees($id){
    $db=Typecho_Db::get();
    $u_yqm = $db->fetchRow($db->select('count(*)')->from('table.tepass_fees')->where('fee_uid = ?',$id)->where('	fee_status=?', '1'));
	$paysum = $u_yqm['count(*)'];    
	return $paysum;
}

// 判断消费金额 
function payjiage($id){
    $db=Typecho_Db::get();
    $postnum=$db->fetchRow($db->select(array('Sum(fee_total_price)'=>'alljiage'))->from ('table.tepass_fees')->where ('fee_uid=?',$id)->where('fee_status=?', '1'));
	$postnum = $postnum['alljiage'];  
	if($postnum){
	return $postnum;
	}
	else{
	return '0';    
	}
}


// 历史订单查询 
function paylist($id){
 
	$db = Typecho_Db::get();
    $result = $db->fetchAll($db->select()->from('table.tepass_fees')
        ->where('fee_uid = ?',$id)        
        ->limit(20)        
    );
    if($result){
        foreach($result as $val){  
            $post_cid = $val['fee_cid'];
            $feestatus = $val['fee_status'];
            if($feestatus =='1'){ $feesp = '已购买';}else{  $feesp = '未购买'; }
			$postval =  $db->fetchAll($db->select()->from('table.contents')->where('cid = ?',$post_cid));          
            foreach($postval as $vals){  
             $vals = Typecho_Widget::widget('Widget_Abstract_Contents')->push($vals);
			 $post_title = htmlspecialchars($vals['title']);
             $permalink = $vals['permalink'];
			 echo '<li><i class="icon iconfont icon-ic_right_line1"></i><a href="' .$permalink. '">' .$post_title. ' </a><div class="post__views"><span class="i_fuei">[ '.$feesp.' - ￥'.$val['fee_total_price'].' ]</span></div> </li>';
			}
        }
    }
	else{
      echo "暂无消费";
	}

}


//调用最近登录时间
function get_last_login($userid){
    $now = time();
    $db     = Typecho_Db::get();
    $prefix = $db->getPrefix();
    $row = $db->fetchRow($db->select('activated')->from('table.users')->where('uid = ?', $userid));
    return Typecho_I18n::dateWord($row['activated'], $now);
}


//调用用户注册时间
function reg_login($userid){
    $now = time();
    $db     = Typecho_Db::get();
    $prefix = $db->getPrefix();
    $row = $db->fetchRow($db->select('created')->from('table.users')->where('uid = ?', $userid));
    $ti = Typecho_I18n::dateWord($row['created'], $now);
    $d1 = $row['created'];//过去的某天，你来设定
    $d2 = ceil((time()-$d1)/60/60/24);//现在的时间减去过去的时间，ceil()进一函数
    return $d2;
}

//判断是否有人回复评论 
function on_comment($mid){
   
    $db = Typecho_Db::get();
    $row = $db->fetchRow($db->select()->from('table.comments')->where('parent = ?', $mid)->where('authorId = ?','1'));
    if(count($row)!=null){
      echo '<p class="re_cm">[已回复]</p>';
    }
    else{
      echo '';
    }
}


// 输出最新订单
function pay_list(){
 $db=Typecho_Db::get();  
	$db = Typecho_Db::get();
    $result = $db->fetchAll($db->select()->from('table.tepass_fees') 
		->order('fee_intime',Typecho_Db::SORT_DESC)
        ->where('fee_status=?', '1')   //改为1，筛选是否购买成功的订单记录                 
        ->limit(4)        
    );
    if($result){
        foreach($result as $val){  
            $post_cid = $val['fee_cid'];//文章id
			$post_uid = $val['fee_uid'];//用户id

			$pcval =  $db->fetchAll($db->select()->from('table.contents')->where('cid = ?',$post_cid));//文章id
            foreach($pcval as $pcval){ 
            $pcval = Typecho_Widget::widget('Widget_Abstract_Contents')->push($pcval);
            $pctitle = $pcval['title'];
			$pcurl = $pcval['permalink'];			
			}

			$puval =  $db->fetchAll($db->select()->from('table.users')->where('uid = ?',$post_uid));//用户id
			foreach($puval as $puval){ 
            $puimg = getGravatar($puval['mail']);	
            $puname = $puval['name'];			
			}
            $uico = '<div class="company-honor"><img src="/usr/themes/spzac/img/authen.svg" title="注册用户"></div>';
            if($post_uid == 0){
			$puimg = "/usr/themes/spzac/img/wu-user.png";
			$puname = "游客";
			$uico = '';
			}
			

           echo '<div class="sidebox__content"> <div class="sidebox__user"> <div class="avatar-container"> <div class="navtar__user-img"><img src="'.$puimg.'" width="25px" height="25px" class="navtar"> '.$uico.' </div> </div> <div class="sidebox__user-title"> <h5>'.$puname.'下载了</h5> <p>'.$pctitle.'</p> </div> <a class="sidebox__user-btn" href="'.$pcurl.'"> <i class="icon iconfont icon-ic_add_line"></i> </a> </div> </div> ';


        }
    }
	else{
      echo "暂无消费";
	}

}



// 生成地图
function getxml(){

        $doc = new \DOMDocument('1.0','utf-8');//引入类并且规定版本编码
        $urlset = $doc->createElement("urlset");//创建节点 
        
        $db = Typecho_Db::get();
        $result = $db->fetchAll($db->select()->from('table.contents')
        ->where('status = ?','publish')
        ->where('type = ?', 'post')
        ->where('created <= unix_timestamp(now())', 'post') //添加这一句避免未达到时间的文章提前曝光
        ->limit(100)
        ->order('created', Typecho_Db::SORT_DESC)
        );
        if($result){
        foreach($result as $val){            
            $val = Typecho_Widget::widget('Widget_Abstract_Contents')->push($val);
            $permalink = $val['permalink'];
            $created = date('Y-m-d', $val['created']);   
                
        /*循环输出节点*/        
        $url = $doc->createElement("url");//创建节点  
		$loc = $doc->createElement("loc");//创建节点
		$lastmod = $doc->createElement("lastmod");//创建节点
		$urlset->appendChild($url);//
        $url->appendChild($loc);//讲loc放到url下
		$url->appendChild($lastmod );
        $content = $doc -> createTextNode($permalink);//设置标签内容
        $contime = $doc -> createTextNode($created);//设置标签内容
        $loc  -> appendChild($content);//将标签内容赋给标签
		$lastmod  -> appendChild($contime);//将标签内容赋给标签    
        
        }}

        $doc->appendChild($urlset);//创建顶级节点
        $doc->save("./../sitemap.xml");//保存代码
        echo "<script>alert('地图生成')</script>";
}


/**
 * 幻灯片处理
 */
function hpianinfo()
{   
  
        $settings = Helper::options()->webhdp;
        $navtops_list = array();
	if (strpos($settings,'|')) {
			//解析关键词数组
			$kwsets = array_filter(preg_split("/(\r|\n|\r\n)/",$settings));
			foreach ($kwsets as $kwset) {
			$navtops_list[] = explode('|',$kwset);
			}
		}
	ksort($navtops_list);  //对关键词排序，短词排在前面	
    if($navtops_list){
        $readnum = 0;
		$i = 0;
		$j = 1;		
        foreach ($navtops_list as $key => $val) {			
            $url = $val[$i];       

			$str = '<div class="swiper-slide"><a href="'.$url.'" ><img src=" '.$val[$j].'"></a></div>';
            
                $readnum += 1;
				echo $str;
                //$content = substr_replace($content,$str,$str_index,$len);
                //$content = $this->str_replace_limit($title,$str,$content,$this->limit);
          
            if($readnum == 4) {
			//匹配到8个关键词就退出
			$i += 2;
            $j += 2;           
            }
		}
    }

   
}




/**
* 阅读统计
* 调用<?php Postviews($this); ?>
*/
function Postviews($archive) {
    $db = Typecho_Db::get();
    $cid = $archive->cid;
    if (!array_key_exists('views', $db->fetchRow($db->select()->from('table.contents')))) {
        $db->query('ALTER TABLE `'.$db->getPrefix().'contents` ADD `views` INT(10) DEFAULT 0;');
    }
    $exist = $db->fetchRow($db->select('views')->from('table.contents')->where('cid = ?', $cid))['views'];
    if ($archive->is('single')) {
        $cookie = Typecho_Cookie::get('contents_views');
        $cookie = $cookie ? explode(',', $cookie) : array();
        if (!in_array($cid, $cookie)) {
            $db->query($db->update('table.contents')
                ->rows(array('views' => (int)$exist+1))
                ->where('cid = ?', $cid));
            $exist = (int)$exist+1;
            array_push($cookie, $cid);
            $cookie = implode(',', $cookie);
            Typecho_Cookie::set('contents_views', $cookie);
        }
    }
    
  
    if( $exist == 0 ){
      echo '0';
    }
    else{      
      $exist = convert($exist);
      echo $exist;
    }
}

function convert($num) 
{
    if ($num >= 100000)
    {
        $num = round($num / 10000) .'w';
    } 
    else if ($num >= 10000) 
    {
        $num = round($num / 10000, 1) .'w';
    } 
    else if($num >= 1000) 
    {
        $num = round($num / 1000, 1) . 'k';
    }

    return $num;
}


/**
* 评论者主页链接新窗口打开
* 调用<?php CommentAuthor($comments); ?>
*/
function CommentAuthor($obj, $autoLink = NULL, $noFollow = NULL) {    //后两个参数是原生函数自带的，为了保持原生属性，我并没有删除，原版保留
    $options = Helper::options();
    $autoLink = $autoLink ? $autoLink : $options->commentsShowUrl;    //原生参数，控制输出链接（开关而已）
    $noFollow = $noFollow ? $noFollow : $options->commentsUrlNofollow;    //原生参数，控制输出链接额外属性（也是开关而已...）
    if ($obj->url && $autoLink) {
        echo '<a href="'.$obj->url.'"'.($noFollow ? ' rel="external nofollow"' : NULL).(strstr($obj->url, $options->index) == $obj->url ? NULL : ' target="_blank"').'>'.$obj->author.'</a>';
    } else {
        echo $obj->author;
    }
}

/** 输出文章缩略图 */
function showThumbnail($widget,$imgnum){ //获取两个参数，文章的ID和需要显示的图片数量
    // 当文章无图片时的默认缩略图
    $rand = rand(1,20); 
    $random = $widget->widget('Widget_Options')->themeUrl . '/images/thumbs/adimg.png'; // 缩略图路径
    $attach = $widget->attachments(1)->attachment;
    $pattern = '/\<img.*?src\=\"(.*?)\"[^>]*>/i'; 
    $patternMD = '/\!\[.*?\]\((http(s)?:\/\/.*?(jpg|png))/i';
    $patternMDfoot = '/\[.*?\]:\s*(http(s)?:\/\/.*?(jpg|png))/i';
    //如果文章内有插图，则调用插图
    if (preg_match_all($pattern, $widget->content, $thumbUrl)) { 
        return $thumbUrl[1][$imgnum];
    }    
    //如果是内联式markdown格式的图片
    else if (preg_match_all($patternMD, $widget->content, $thumbUrl)) {
        return $thumbUrl[1][$imgnum];
    }
    //如果是脚注式markdown格式的图片
    else if (preg_match_all($patternMDfoot, $widget->content, $thumbUrl)) {
        return $thumbUrl[1][$imgnum];
    }
    //没有就调用第一个图片附件
    else if ($attach && $attach->isImage) {
        return $attach->url; 
    } 
    //如果真的没有图片，就调用一张随机图片
    else{
        return $random;
    }
}

//获取Gravatar头像 QQ邮箱取用qq头像
function getGravatar($email, $s = 96, $d = 'mp', $r = 'g', $img = false, $atts = array())
{
preg_match_all('/((\d)*)@qq.com/', $email, $vai);
if (empty($vai['1']['0'])) {
    $url = 'https://cdn.v2ex.com/gravatar/';
    $url .= md5(strtolower(trim($email)));
    $url .= "?s=$s&d=$d&r=$r";
    if ($img) {
        $url = '<img src="' . $url . '"';
        foreach ($atts as $key => $val)
            $url .= ' ' . $key . '="' . $val . '"';
        $url .= ' />';
    }
}else{
    $url = 'https://q2.qlogo.cn/headimg_dl?dst_uin='.$vai['1']['0'].'&spec=100';
}
return  $url;
}

//博客最后更新时间
function get_last_update(){
    $num   = '1'; //取最近的一笔就好了
    $now = time();
    $db     = Typecho_Db::get();
    $prefix = $db->getPrefix();
    $create = $db->fetchRow($db->select('created')->from('table.contents')->limit($num)->order('created',Typecho_Db::SORT_DESC));
    $update = $db->fetchRow($db->select('modified')->from('table.contents')->limit($num)->order('modified',Typecho_Db::SORT_DESC));
    if($create>=$update){  //发表时间和更新时间取最近的
      echo Typecho_I18n::dateWord($create['created'], $now); //转换为更通俗易懂的格式
    }else{
      echo Typecho_I18n::dateWord($update['modified'], $now);
    }
}

/**
 * 文章链接新窗口打开
 */
function uericoimg($userid){ 
        $obj = Helper::options()->uerico;	
        return $obj;
 }


//热门访问量文章
function theMostViewed($limit = 4, $before = '<br/> - ( views: ', $after = ' times ) ')
    {
        $db = Typecho_Db::get();
        $options = Typecho_Widget::widget('Widget_Options');
        $limit = is_numeric($limit) ? $limit : 5;
        $posts = $db->fetchAll($db->select()->from('table.contents')
                 ->where('type = ? AND status = ? AND password IS NULL', 'post', 'publish')
                 ->order('views', Typecho_Db::SORT_DESC)
                 ->limit($limit)
                 );
        if ($posts) {
            foreach ($posts as $post) {
                $result = Typecho_Widget::widget('Widget_Abstract_Contents')->push($post);
                $post_views = convert($result['views']);              
                $post_title = htmlspecialchars($result['title']);
                $permalink = $result['permalink'];
				$created = date('m-d', $result['created']);            
			   $tdescs =  $db->fetchAll($db->select()->from('table.fields')->where('name = ? AND cid = ?','tdesc',$result['cid']));
			   if(count($tdescs) !=0){
						//var_dump($img);
						$tdesc=$tdescs['0']['str_value'];						
                        if($tdesc){}
						else{     
                          $post_text = preg_replace('/($s*$)|(^s*^)/m', '',strip_tags($result['text'])); //获取内容
$tdesc = mb_strlen($post_text, 'utf-8') > 25 ? mb_substr($post_text, 0, 25, 'utf-8').'....' : $post_text; //格式化内容
						}                        						 
					}
            else{    $post_text = preg_replace('/($s*$)|(^s*^)/m', '',strip_tags($result['text'])); //获取内容
$tdesc = mb_strlen($post_text, 'utf-8') > 25 ? mb_substr($post_text, 0, 25, 'utf-8').'....' : $post_text; //格式化内容
                } 
									
					// var_dump($img);
					// if($img == ""){
					// 	$img = "wu";
					// }
               
			    echo "<div class='sidebox__job'><div class='sidebox__job-title'><a href='$permalink'>$post_title</a><span>$post_views 阅读</span></div><p class='sidebox__job-description'>$tdesc</p></div>";              
      
			   
            }

        } else {
            echo "<li>N/A</li>\n";
        }
}


//热门评论文章
function getHotPosts($limit = 10){
    $db = Typecho_Db::get();
    $result = $db->fetchAll($db->select()->from('table.contents')
        ->where('status = ?','publish')
        ->where('type = ?', 'post')
        ->where('created <= unix_timestamp(now())', 'post') //添加这一句避免未达到时间的文章提前曝光
        ->limit($limit)
        ->order('commentsNum', Typecho_Db::SORT_DESC)
    );
    if($result){
        foreach($result as $val){            
            $val = Typecho_Widget::widget('Widget_Abstract_Contents')->push($val);
            $post_title = htmlspecialchars($val['title']);
            $permalink = $val['permalink'];
           
			echo '<div class="sidebox__job"><div class="sidebox__job-title"><a href="' .$permalink. '">' .$post_title. '</a><span>' . $val['commentsNum'] . ' 评论 </span></div></div>'; 
        }
    }
}






/**
* 文章访问量等级
*/

function listdeng($archive){
   $db = Typecho_Db::get();
    $cid = $archive->cid;
    if (!array_key_exists('views', $db->fetchRow($db->select()->from('table.contents')))) {
        $db->query('ALTER TABLE `'.$db->getPrefix().'contents` ADD `views` INT(10) DEFAULT 0;');
    }
    $exist = $db->fetchRow($db->select('views')->from('table.contents')->where('cid = ?', $cid))['views'];
    if($exist<200){
   /** echo '<span class="badge arc_v1"></span>';**/
    }elseif ($exist<500 && $exist>200) {
    echo '<span class="badge arc_v2">新秀</span>';
    }elseif ($exist<1000 && $exist>=500) {
    echo '<span class="badge arc_v3">推荐</span>';
    }elseif ($exist<5000 && $exist>=1000) {
    echo '<span class="badge arc_v4">热文</span>';
    }elseif ($exist<10000 && $exist>=5000) {
    echo '<span class="badge arc_v5">头条</span>';
    }elseif ($exist<30000 && $exist>=10000) {
    echo '<span class="badge arc_v6">火爆</span>';
    }elseif ($exist>=30000) {
    echo '<span class="badge arc_v7">神贴</span>';
    }
}


/**
* 显示会员用户评论次数，按id
*/

function plium($i){
    $db=Typecho_Db::get();
    $mail=$db->fetchAll($db->select(array('COUNT(cid)'=>'rbq'))->from('table.comments')->where('authorId = ?', $i)/**->where('authorId = ?','0')**/);
    foreach ($mail as $sl){
    $rbq=$sl['rbq'];}
   
    echo $rbq;
}


/**
* 获取文章图片数量
*/

function imgNum($content){
$output = preg_match_all('#<img(.*?) src="([^"]*/)?(([^"/]*)\.[^"]*)"(.*?)>#', $content,$s);
$cnt = count( $s[1] );
return $cnt;
}

/**
* 随机文章
*/
function getRandomPosts($random=5){
    $db = Typecho_Db::get();
    $adapterName = $db->getAdapterName();//兼容非MySQL数据库
    if($adapterName == 'pgsql' || $adapterName == 'Pdo_Pgsql' || $adapterName == 'Pdo_SQLite' || $adapterName == 'SQLite'){
        $order_by = 'RANDOM()';
    }else{
        $order_by = 'RAND()';
    }
    $sql = $db->select()->from('table.contents')
        ->where('status = ?','publish')
        ->where('table.contents.created <= ?', time())
        ->where('type = ?', 'post')
        ->limit($random)
        ->order($order_by);

$result = $db->fetchAll($sql);
if($result){
    foreach($result as $val){
        $obj = Typecho_Widget::widget('Widget_Abstract_Contents');
        $val = $obj->push($val);
        $post_title = htmlspecialchars($val['title']);
        $permalink = $val['permalink'];
		$created = date('m-d', $val['created']);
		$img =  $db->fetchAll($db->select()->from('table.fields')->where('name = ? AND cid = ?','img',$val['cid']));
					if(count($img) !=0){
						//var_dump($img);
						$img=$img['0']['str_value'];						
                        if($img){}
						else{
                         $img="/usr/themes/spzac/images/thumbs/adimg.png";
						}                        						 
					}
        $cdnopen = Helper::options()->cdnopen;
            if ($cdnopen == '0'){ $strimg = $img;} else{ $strimg = str_replace(Helper::options()->cdnurla,Helper::options()->cdnurlb,$img);}    
            if ($strimg){$strimg=$strimg;}else{$strimg = "/usr/themes/spzac/images/thumbs/adimg.png";}
        echo '<li><i class="icon iconfont icon-ic_right_line1"></i><a href="'.$permalink.'">'.$post_title.'</a></li>';


    
    }
}
}




/**
* 判断时间区间
*
* 使用方法  if(timeZone($this->date->timeStamp)) echo 'ok';
*/
function timeZone($from){
$now = new Typecho_Date(Typecho_Date::gmtTime());
return $now->timeStamp - $from < 24*60*60 ? true : false;
}





/**输出最新注册用户*/
function newones($sta,$stu){
    $db = Typecho_Db::get();
    $userinfo=$db->fetchAll($db->select()->from ('table.users')->limit($stu)->order('created',Typecho_Db::SORT_DESC));
    if($userinfo){
            foreach($userinfo as $vual){ 
            $imgUrl = getGravatar($vual['mail']);
            $now = time();
            $time = Typecho_I18n::dateWord($vual['created'], $now); 
            $siteUrl = Helper::options()->siteUrl;  
            if(Helper::options()->rewrite==0){  $siteUrl = $siteUrl.'index.php/'; }    
            if($sta ==1 ) {
            $c_url = '<div class="header__ntf"><a href="'.$siteUrl.'author/'.$vual['uid'].'" class="header__ntf-img"><img src="'.$imgUrl.'" alt=""></a><h6 class="header__ntf-title"><span>' . $vual['screenName'] . '</span> - ' . $time . '注册会员;</h6></div>';
            echo $c_url; 
            }
            if($sta ==2) {
            $c_url = '<div class="col-12 col-sm-6 col-md-12 col-lg-3">
<div class="company uers_list">
<div class="company__logo"><img src="'.$imgUrl.'" alt=""></div>
<div class="company__wrap"><h2 class="company__title"><a href="'.$siteUrl.'author/'.$vual['uid'].'">' . $vual['screenName'] . '</a></h2>
<p class="company__text">注册会员</p>
</div></div></div>';              
            echo $c_url;  
            }
            }}    
}






/** HTML压缩功能 */
function compressHtml($html_source) {
    $chunks = preg_split('/(<!--<nocompress>-->.*?<!--<\/nocompress>-->|<nocompress>.*?<\/nocompress>|<pre.*?\/pre>|<textarea.*?\/textarea>|<script.*?\/script>)/msi', $html_source, -1, PREG_SPLIT_DELIM_CAPTURE);
    $compress = '';
    foreach ($chunks as $c) {
        if (strtolower(substr($c, 0, 19)) == '<!--<nocompress>-->') {
            $c = substr($c, 19, strlen($c) - 19 - 20);
            $compress .= $c;
            continue;
        } else if (strtolower(substr($c, 0, 12)) == '<nocompress>') {
            $c = substr($c, 12, strlen($c) - 12 - 13);
            $compress .= $c;
            continue;
        } else if (strtolower(substr($c, 0, 4)) == '<pre' || strtolower(substr($c, 0, 9)) == '<textarea') {
            $compress .= $c;
            continue;
        } else if (strtolower(substr($c, 0, 7)) == '<script' && strpos($c, '//') != false && (strpos($c, "\r") !== false || strpos($c, "\n") !== false)) {
            $tmps = preg_split('/(\r|\n)/ms', $c, -1, PREG_SPLIT_NO_EMPTY);
            $c = '';
            foreach ($tmps as $tmp) {
                if (strpos($tmp, '//') !== false) {
                    if (substr(trim($tmp), 0, 2) == '//') {
                        continue;
                    }
                    $chars = preg_split('//', $tmp, -1, PREG_SPLIT_NO_EMPTY);
                    $is_quot = $is_apos = false;
                    foreach ($chars as $key => $char) {
                        if ($char == '"' && $chars[$key - 1] != '\\' && !$is_apos) {
                            $is_quot = !$is_quot;
                        } else if ($char == '\'' && $chars[$key - 1] != '\\' && !$is_quot) {
                            $is_apos = !$is_apos;
                        } else if ($char == '/' && $chars[$key + 1] == '/' && !$is_quot && !$is_apos) {
                            $tmp = substr($tmp, 0, $key);
                            break;
                        }
                    }
                }
                $c .= $tmp;
            }
        }
        $c = preg_replace('/[\\n\\r\\t]+/', ' ', $c);
        $c = preg_replace('/\\s{2,}/', ' ', $c);
        $c = preg_replace('/>\\s</', '> <', $c);
        $c = preg_replace('/\\/\\*.*?\\*\\//i', '', $c);
        $c = preg_replace('/<!--[^!]*-->/', '', $c);
        $compress .= $c;
    }
    return $compress;
}




/**
 * 文章链接新窗口打开
 */

function parseContent($obj){ 
        $obj = preg_replace("/<a href=\"([^\"]*)\">/i", "<a href=\"\\1\" target=\"_blank\" >", $obj);
        return $obj;
 }


/*输出作者发表的评论*/
class Widget_Post_AuthorComment extends Widget_Abstract_Comments
{
    public function execute()
    {
        global $AuthorCommentId;//全局作者id
        $select  = $this->select()->limit($this->parameter->pageSize)
        ->where('table.comments.status = ?', 'approved')
        ->where('table.comments.authorId = ?', $AuthorCommentId)//获取作者id
        ->where('table.comments.type = ?', 'comment')
        ->order('table.comments.coid', Typecho_Db::SORT_DESC);//根据coid排序
        $this->db->fetchAll($select, array($this, 'push'));
    }
}


/** 列表衍射文章 */
function cosmore($str){
if ( strpos( $str, '[post')!== false) {//提高效率，避免每篇文章都要解析    
   preg_match_all("/\[post\](.*?)\[\/post\]/sm",$str,$strcid);
   
   echo '<span class="lirekan"><i class="icon iconfont icon-chuangzuo1"></i> 扩展看点 </span><ul class="lire">';
  
   for($i=0;$i<count($strcid[1]);$i++){
     $scid =  $strcid[1][$i];     
    $db = Typecho_Db::get();
    $result = $db->fetchAll($db->select()->from('table.contents')->where('cid = ?', $scid));
    if($result){
        foreach($result as $val){ 
          $val = Typecho_Widget::widget('Widget_Abstract_Contents')->push($val);
            $post_title = htmlspecialchars($val['title']);
            $permalink = $val['permalink'];
            $post_views = number_format($val['views']);
            $created = date('m-d', $val['created']);
            $strhtml = '<li><a href="'.$permalink.'"><i class="icon iconfont icon-icon-test29"></i> '.$post_title.'</a><div class="liretime">'.$created.'</div></li>';
            echo $strhtml;
        }
    }
   }
    echo  '</ul>';
} 
}

/** 后台编辑器文章输出 */
function costcn($cid,$mid,$str,$status){
  
//回复可见
if ( strpos( $str, '[hide')!== false) {//提高效率，避免每篇文章都要解析  
  
$db = Typecho_Db::get();
$sql = $db->select()->from('table.comments')
    ->where('cid = ?',$cid)
    ->where('mail = ?', $mid)
    ->where('status = ?', 'approved')
//只有通过审核的评论才能看回复可见内容
    ->limit(1);
$result = $db->fetchAll($sql);
if($status || $result) {
    $str = preg_replace("/\[hide\](.*?)\[\/hide\]/sm",'<div class="reply2view">$1</div>',$str);
}
else{
    $str = preg_replace("/\[hide\](.*?)\[\/hide\]/sm",'<div class="reply2view">此处内容需要评论回复后</div>',$str);
}  
}  

//提示框短代码
if ( strpos( $str, '[scode')!== false) {//提高效率，避免每篇文章都要解析
  //[scode class="red"]这里编辑标签内容//[/scode]   
   $str = preg_replace("/\[scode\](.*?)\[\/scode\]/sm",'<div class="tip ">$1</div>',$str);
}  
  
//调用其他文章短代码
if ( strpos( $str, '[post')!== false) {//提高效率，避免每篇文章都要解析  
   preg_match_all("/\[post\](.*?)\[\/post\]/sm",$str,$strcid);

for($i=0;$i<count($strcid[1]);$i++){
    $scid =  $strcid[1][$i];     
    $db = Typecho_Db::get();
    $result = $db->fetchAll($db->select()->from('table.contents')->where('cid = ?', $scid));
    if($result){
        foreach($result as $val){            
            $val = Typecho_Widget::widget('Widget_Abstract_Contents')->push($val);
            $post_title = htmlspecialchars($val['title']);
            $permalink = $val['permalink'];
            $post_text = preg_replace('/($s*$)|(^s*^)/m', '',strip_tags($val['text'])); //获取内容
            $cont_text = mb_strlen($post_text, 'utf-8') > 85 ? mb_substr($post_text, 0, 85, 'utf-8').'....' : $post_text; //格式化内容
            $post_views = number_format($val['views']);
            $created = date('m-d', $val['created']);
            $pnum = $val['commentsNum'];
            $auinfo =  $db->fetchAll($db->select()->from('table.comments')->where('authorId = ?',$val['authorId']));
					if(count($auinfo) !=0){
						//var_dump($img);
						$mail=$auinfo['0']['mail'];					
                        $imgUrl = getGravatar($mail);
						$author= $auinfo['0']['author'];
					}
            $img =  $db->fetchAll($db->select()->from('table.fields')->where('name = ? AND cid = ?','img',$scid));
					if(count($img) !=0){
						//var_dump($img);
						$img=$img['0']['str_value'];						
                        if($img){}
						else{
                         $img="/usr/themes/spzac/images/thumbs/adimg.png";
						}                        						 
					}
            $cdnopen = Helper::options()->cdnopen;
            if ($cdnopen == '0'){ $strimg = $img;} else{ $strimg = str_replace(Helper::options()->cdnurla,Helper::options()->cdnurlb,$img);}
            
			



              $html='<div class="bid">
<div class="bid__head">
<a href="' .$permalink. '" class="bid__head-img">
<img src="' .$strimg. '" alt="">
</a>
<div class="bid__head-title">
<h5><a href="' .$permalink. '">' .$post_title. '</a></h5>
<p>

<span>' . $cont_text . '</span>
</p>
</div>
</div>
</div>'; 

          
        }
    }
    
   $str = preg_replace("/\[post\](".$scid.")\[\/post\]/sm",$html,$str);
  
  }
  
}    
   return $cosen=$str;
}


// 获取浏览器信息
function getBrowser($agent)
{
    if (preg_match('/MSIE\s([^\s|;]+)/i', $agent, $regs)) {
        $outputer = '<i class="ua-icon icon-ie"></i>&nbsp;&nbsp;Internet Explore';
    } else if (preg_match('/FireFox\/([^\s]+)/i', $agent, $regs)) {
      $str1 = explode('Firefox/', $regs[0]);
$FireFox_vern = explode('.', $str1[1]);
        $outputer = '<i class="ua-icon icon-firefox"></i>&nbsp;&nbsp;FireFox';
    } else if (preg_match('/Maxthon([\d]*)\/([^\s]+)/i', $agent, $regs)) {
      $str1 = explode('Maxthon/', $agent);
$Maxthon_vern = explode('.', $str1[1]);
        $outputer = '<i class="ua-icon icon-edge"></i>&nbsp;&nbsp;MicroSoft Edge';
    } else if (preg_match('#360([a-zA-Z0-9.]+)#i', $agent, $regs)) {
$outputer = '<i class="ua-icon icon-360"></i>&nbsp;&nbsp;360极速浏览器';
    } else if (preg_match('/Edge([\d]*)\/([^\s]+)/i', $agent, $regs)) {
        $str1 = explode('Edge/', $regs[0]);
$Edge_vern = explode('.', $str1[1]);
        $outputer = '<i class="ua-icon icon-edge"></i>&nbsp;&nbsp;MicroSoft Edge';
    } else if (preg_match('/UC/i', $agent)) {
              $str1 = explode('rowser/',  $agent);
$UCBrowser_vern = explode('.', $str1[1]);
        $outputer = '<i class="ua-icon icon-uc"></i>&nbsp;&nbsp;UC浏览器';
    }  else if (preg_match('/QQ/i', $agent, $regs)||preg_match('/QQBrowser\/([^\s]+)/i', $agent, $regs)) {
                  $str1 = explode('rowser/',  $agent);
$QQ_vern = explode('.', $str1[1]);
        $outputer = '<i class= "ua-icon icon-qq"></i>&nbsp;&nbsp;QQ浏览器';
    } else if (preg_match('/UBrowser/i', $agent, $regs)) {
              $str1 = explode('rowser/',  $agent);
$UCBrowser_vern = explode('.', $str1[1]);
        $outputer = '<i class="ua-icon icon-uc"></i>&nbsp;&nbsp;UC浏览器';
    }  else if (preg_match('/Opera[\s|\/]([^\s]+)/i', $agent, $regs)) {
        $outputer = '<i class= "ua-icon icon-opera"></i>&nbsp;&nbsp;Opera';
    } else if (preg_match('/Chrome([\d]*)\/([^\s]+)/i', $agent, $regs)) {
$str1 = explode('Chrome/', $agent);
$chrome_vern = explode('.', $str1[1]);
        $outputer = '<i class="ua-icon icon-chrome"></i>&nbsp;&nbsp;Chrome';
    } else if (preg_match('/safari\/([^\s]+)/i', $agent, $regs)) {
         $str1 = explode('Version/',  $agent);
$safari_vern = explode('.', $str1[1]);
        $outputer = '<i class="ua-icon icon-safari"></i>&nbsp;&nbsp;Safari';
    } else{
        $outputer = '<i class="ua-icon icon-chrome"></i>&nbsp;&nbsp;Google Chrome';
    }
    echo $outputer;
}
// 获取操作系统信息
function getOs($agent)
{
    $os = false;
 
    if (preg_match('/win/i', $agent)) {
        if (preg_match('/nt 6.0/i', $agent)) {
            $os = '&nbsp;&nbsp;<i class= "ua-icon icon-win1"></i>&nbsp;&nbsp;Win Vista&nbsp;/&nbsp;';
        } else if (preg_match('/nt 6.1/i', $agent)) {
            $os = '&nbsp;&nbsp;<i class= "ua-icon icon-win1"></i>&nbsp;&nbsp;Win 7&nbsp;/&nbsp;';
        } else if (preg_match('/nt 6.2/i', $agent)) {
            $os = '&nbsp;&nbsp;<i class="ua-icon icon-win2"></i>&nbsp;&nbsp;Win 8&nbsp;/&nbsp;';
        } else if(preg_match('/nt 6.3/i', $agent)) {
            $os = '&nbsp;&nbsp;<i class= "ua-icon icon-win2"></i>&nbsp;&nbsp;Win 8.1&nbsp;/&nbsp;';
        } else if(preg_match('/nt 5.1/i', $agent)) {
            $os = '&nbsp;&nbsp;<i class="ua-icon icon-win1"></i>&nbsp;&nbsp;Win XP&nbsp;/&nbsp;';
        } else if (preg_match('/nt 10.0/i', $agent)) {
            $os = '&nbsp;&nbsp;<i class="ua-icon icon-win2"></i>&nbsp;&nbsp;Win 10&nbsp;/&nbsp;';
        } else{
            $os = '&nbsp;&nbsp;<i class="ua-icon icon-win2"></i>&nbsp;&nbsp;Win X64&nbsp;/&nbsp;';
        }
    } else if (preg_match('/android/i', $agent)) {
    if (preg_match('/android 9/i', $agent)) {
            $os = '&nbsp;&nbsp;<i class="ua-icon icon-android"></i>&nbsp;&nbsp;Android&nbsp;/&nbsp;';
        }
    else if (preg_match('/android 8/i', $agent)) {
            $os = '&nbsp;&nbsp;<i class="ua-icon icon-android"></i>&nbsp;&nbsp;Android&nbsp;/&nbsp;';
        }
    else{
            $os = '&nbsp;&nbsp;<i class="ua-icon icon-android"></i>&nbsp;&nbsp;Android&nbsp;/&nbsp;';
    }
    }
    else if (preg_match('/ubuntu/i', $agent)) {
        $os = '&nbsp;&nbsp;<i class="ua-icon icon-ubuntu"></i>&nbsp;&nbsp;Ubuntu&nbsp;/&nbsp;';
    } else if (preg_match('/linux/i', $agent)) {
        $os = '&nbsp;&nbsp;<i class= "ua-icon icon-linux"></i>&nbsp;&nbsp;Linux&nbsp;/&nbsp;';
    } else if (preg_match('/iPhone/i', $agent)) {
        $os = '&nbsp;&nbsp;<i class="ua-icon icon-apple"></i>&nbsp;&nbsp;iPhone&nbsp;/&nbsp;';
    } else if (preg_match('/mac/i', $agent)) {
        $os = '&nbsp;&nbsp;<i class="ua-icon icon-mac"></i>&nbsp;&nbsp;MacOS&nbsp;/&nbsp;';
    }else if (preg_match('/fusion/i', $agent)) {
        $os = '&nbsp;&nbsp;<i class="ua-icon icon-android"></i>&nbsp;&nbsp;Android&nbsp;/&nbsp;';
    } else {
        $os = '&nbsp;&nbsp;<i class="ua-icon icon-linux"></i>&nbsp;&nbsp;Linux&nbsp;/&nbsp;';
    }
    echo $os;
}



//获取评论的锚点链接
function get_comment_at($coid)
{
    $db   = Typecho_Db::get();
    $prow = $db->fetchRow($db->select('parent,status')->from('table.comments')
        ->where('coid = ?', $coid));//当前评论
    $mail = "";
    $parent = @$prow['parent'];
    if ($parent != "0") {//子评论
        $arow = $db->fetchRow($db->select('author,status,mail')->from('table.comments')
            ->where('coid = ?', $parent));//查询该条评论的父评论的信息
        @$author = @$arow['author'];//作者名称
        $mail = @$arow['mail'];
        if(@$author && $arow['status'] == "approved"){//父评论作者存在且父评论已经审核通过
            if (@$prow['status'] == "waiting"){
                echo '<p class="commentReview">'._mt("（评论审核中）").'</p>';
            }
            echo '<a href="#comment-' . $parent . '">@' . $author . '</a>';
        }else{//父评论作者不存在或者父评论没有审核通过
            if (@$prow['status'] == "waiting"){
                echo '<p class="commentReview">'._mt("（评论审核中）").'</p>';
            }else{
                echo '';
            }

        }

    } else {//母评论，无需输出锚点链接
        if (@$prow['status'] == "waiting"){
            echo '<p class="commentReview">'._mt("（评论审核中）").'</p>';
        }else{
            echo '';
        }
    }


}

/**
 * 加载时间
 * @return bool
 */
function timer_start() {
    global $timestart;
    $mtime     = explode( ' ', microtime() );
    $timestart = $mtime[1] + $mtime[0];
    return true;
}
timer_start();
function timer_stop( $display = 0, $precision = 3 ) {
    global $timestart, $timeend;
    $mtime     = explode( ' ', microtime() );
    $timeend   = $mtime[1] + $mtime[0];
    $timetotal = number_format( $timeend - $timestart, $precision );
    $r         = $timetotal < 1 ? $timetotal * 1000 . " ms" : $timetotal . " s";
    if ( $display ) {
        echo $r;
    }
    return $r;
}


/**
 * 回复触发
 */
Typecho_Plugin::factory('Widget_Feedback')->comment = array('ComWechat', 'sc_send');
class ComWechat {
    public static function sc_send($comment, $post)
    {       
     
      
        if ($comment['authorId'] == 1) {
            return $comment;
        }   
       $sckey = Helper::options()->iyuukey;
        
       $text = "有人在您的博客发表了评论";
       $desp = "**".$comment['author']."** 在 [「".$post->title."」](".$post->permalink." \"".$post->title."\") 中说到: \n\n > ".$comment['text'];      
      
        $postdata = http_build_query(
    array(
        'text' => $text,
        'desp' => $desp
        )
    );
$opts = array('http' =>array(
        'method'  => 'POST',
        'header'  => 'Content-type: application/x-www-form-urlencoded',
        'content' => $postdata
        ),
        // 解决SSL证书验证失败的问题
        "ssl"=>array(
            "verify_peer"=>false,
            "verify_peer_name"=>false,
        )
    );
$context  = stream_context_create($opts);
$result = file_get_contents('https://iyuu.cn/'. $sckey .'.send', false, $context);
      
      
        return  $comment;      
    }
}



/**
 * 后台编辑器
 */
Typecho_Plugin::factory('admin/write-post.php')->bottom = array('tagshelper', 'tagslist');
Typecho_Plugin::factory('admin/write-post.php')->bottom = array('myyodu', 'one');
Typecho_Plugin::factory('admin/write-page.php')->bottom = array('myyodu', 'one');

class myyodu {
    public static function one()
    {      
    ?>
<script src="/usr/themes/spzac/assets/css/wmd.js"></script>

<link rel="stylesheet" href="/usr/themes/spzac/assets/css/setting.fb.css">

<?php
    }
}


class tagshelper {
    public static function tagslist()
    {      
    $tag="";$taglist="";$i=0;//循环一次利用到两个位置
Typecho_Widget::widget('Widget_Metas_Tag_Cloud', 'sort=count&desc=1&limit=200')->to($tags);
while ($tags->next()) {
$tag=$tag."'".$tags->name."',";
$taglist=$taglist."<a id=".$i." onclick=\"$(\'#tags\').tokenInput(\'add\', {id: \'".$tags->name."\', tags: \'".$tags->name."\'});\">".$tags->name."</a>";
$i++;
}
?><style>.Posthelper a{cursor: pointer; padding: 0px 6px; margin: 2px 0;display: inline-block;border-radius: 2px;text-decoration: none;}
.Posthelper a:hover{background: #ccc;color: #fff;}.fullscreen #tab-files{right: 0;}/*解决全屏状态下鼠标放到附件上传按钮上导致的窗口抖动问题*/
</style>
<script>
  function chaall () {
   var html='';
 $("#file-list li .insert").each(function(){
   var t = $(this), p = t.parents('li');
   var file=t.text();
   var url= p.data('url');
   var isImage= p.data('image');
   if ($("input[name='markdown']").val()==1) {
   html = isImage ? html+'\n!['+file+'](' + url + ')\n':''+html+'';
   }else{
   html = isImage ? html+'<img src="' + url + '" alt="' + file + '" />\n':''+html+'';
   }
    });
   var textarea = $('#text');
   textarea.replaceSelection(html);return false;
    }

    function chaquan () {
   var html='';
 $("#file-list li .insert").each(function(){
   var t = $(this), p = t.parents('li');
   var file=t.text();
   var url= p.data('url');
   var isImage= p.data('image');
   if ($("input[name='markdown']").val()==1) {
   html = isImage ? html+'':html+'\n['+file+'](' + url + ')\n';
   }else{
   html = isImage ? html+'':html+'<a href="' + url + '"/>' + file + '</a>\n';
   }
    });
   var textarea = $('#text');
   textarea.replaceSelection(html);return false;
    }
function filter_method(text, badword){
    //获取文本输入框中的内容
    var value = text;
    var res = '';
    //遍历敏感词数组
    for(var i=0; i<badword.length; i++){
        var reg = new RegExp(badword[i],"g");
        //判断内容中是否包括敏感词		
        if (value.indexOf(badword[i]) > -1) {
            $('#tags').tokenInput('add', {id: badword[i], tags: badword[i]});
        }
    }
    return;
}
var badwords = [<?php echo $tag; ?>];
function chatag(){
var textarea=$('#text').val();
filter_method(textarea, badwords); 
}
  $(document).ready(function(){
    $('#file-list').after('<div class="Posthelper"><a class="w-100" onclick=\"chaall()\" style="background: #467B96;background-color: #3c6a81;text-align: center; padding: 5px 0; color: #fbfbfb; box-shadow: 0 1px 5px #ddd;">插入所有图片</a><a class="w-100" onclick=\"chaquan()\" style="background: #467B96;background-color: #3c6a81;text-align: center; padding: 5px 0; color: #fbfbfb; box-shadow: 0 1px 5px #ddd;">插入所有非图片附件</a></div>');
    $('#tags').after('<div style="margin-top: 35px;" class="Posthelper"><ul style="list-style: none;border: 1px solid #D9D9D6;padding: 6px 12px; max-height: 240px;overflow: auto;background-color: #FFF;border-radius: 2px;margin-bottom: 0;"><?php echo $taglist; ?></ul><a class="w-100" onclick=\"chatag()\" style="background: #467B96;background-color: #3c6a81;text-align: center; padding: 5px 0; color: #fbfbfb; box-shadow: 0 1px 5px #ddd;">检测内容插入标签</a></div>');
  });
  </script>
<?php
    }
}
