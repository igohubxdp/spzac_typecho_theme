<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;
include 'lib/common.php';
$this->need('header.php'); 
?>

<?php

$str=$_SERVER["REQUEST_URI"];
if(preg_match('/\d+/',$str,$arr)){
$id=$arr[0];
//0:是自己 1:是别人
if ($this->user->hasLogin()&&$this->user->uid==$id){$GLOBALS['lock']=0;}else{$GLOBALS['lock']=1;}
$info=userok($id);
$myuid=$id;
$myname=$info['name'];
$myscreenName=$info['screenName'];
$mymail=$info['mail'];
$mygroup=$info['group'];
$mypoints=$info['points'];

} ?>


	<!-- main content -->
	<main class="main">
		<div class="container">
			<div class="row">
				
				
				<!-- 会员边栏资料 -->
	            
                <div class="col-12 col-md-5 col-lg-4 col-xl-3">
					<!-- user -->
					<div class="user">
<div class="user__head  bg_color">
<div class="user__img"><div class="avatar-container"> 
<?php $email=$mymail; $imgUrl = getGravatar($email);echo '<img src="'.$imgUrl.'" width="25px" height="25px" >'; ?>
  
<div class="company-honor"><img src="/usr/themes/spzac/img/authen.svg" title="注册用户"></div>  
</div></div>
</div>
<div class="user__title">
<h2><?php echo $myscreenName; ?></h2>
</div>
                      
 					<!-- progress -->

                       
					 
					<!-- end progress -->                     
                      
 
<ul class="user__list">
<li><span>会员类型:</span> <span>注册会员</span></li>
<li><span>会员期限:</span> <span><?php echo ueretime($myuid); ?></span></li>
<li><span>消费次数:</span> <span><?php echo payfees($myuid); ?> 单</span></li>
<li><span>最近登录:</span> <span><?php echo get_last_login($myuid); ?></span></li>  
</ul>                
                      
               
       
                      
<ul class="user__stats">
<li>
<p>Comment</p>
<span><?php plium($myuid);?></span>
</li>
<li>
<p>Your age</p>
<span><?php echo reg_login($myuid); ?></span>
</li>
</ul>                   
                
                      
</div>
<!-- end user -->


				</div>

	            <!-- 边栏资料 -->
  
               <div class="col-12 col-md-7 col-lg-8 col-xl-9 author_one">

                   <!-- view big -->
	    
                   <ul class="nav nav-tabs main__nav" id="main__nav" role="tablist">
						<li class="nav-item">
							<a class="nav-link active" id="btnon" data-toggle="tab" href="#tab-1" role="tab" aria-controls="tab-1" aria-selected="false">常规设置</a>
						</li>

						<li class="nav-item">
							<a class="nav-link" id="btnoff" data-toggle="tab" href="#tab-2" role="tab" aria-controls="tab-2" aria-selected="true">消费记录</a>
						</li>

						<li class="nav-item">
							<a class="nav-link" id="btnoff" data-toggle="tab" href="#tab-3" role="tab" aria-controls="tab-3" aria-selected="false">                  
                            官网公告</a>
						</li> 
                     
                        
					</ul>
                   

                    <div class="tab-content">
					<div class="tab-pane fade show active pagecontent" id="tab-1" role="tabpanel" aria-labelledby="tab-1">
					<!-- post -->
					 <div class="main__box">
							<!-- form -->
                                <?php Typecho_Widget::widget('Widget_Security')->to($security); ?>
                                <form action="<?php $security->index('/action/users-profile'); ?>" method="post" class="input-form form" name=forma enctype="application/x-www-form-urlencoded">
							
								<div class="row">
									<div class="col-12">
										<h2 class="form__title">用户中心</h2>                                        
									</div>
                                  
                                    <?php if($mygroup == 'administrator'||$mygroup == 'contributor'): ?>
                                  

                              
                                    <?php endif; ?>
                                  
                                     <?php if($GLOBALS['lock']==0): ?>   
                                     
                                  
                                    <div class="col-12 col-lg-6">
										<div class="form__group">
											<label class="form__label">用户ID	:</label>
											<input name="username"  type="text" class="form__input" value="<?php echo $myuid; ?>" readonly  unselectable="on">
										</div>
									</div>

									<div class="col-12 col-lg-6">
										<div class="form__group">
											<label class="form__label">帐号:</label>
											<input name="title"  type="text" class="form__input" value="<?php echo $myname; ?>" readonly  unselectable="on">
										</div>
									</div>
                                   <?php endif; ?>
                                  
									<div class="col-12 col-lg-6">
										<div class="form__group">
											<label class="form__label">昵称:</label>
											<input name="screenName"  type="text" class="form__input" value="<?php echo $myscreenName; ?>" <?php if($GLOBALS['lock']==1): ?> readonly  unselectable="on"<?php endif; ?>>
										</div>
									</div>

									<div class="col-12 col-lg-6">
										<div class="form__group">
											<label class="form__label">邮箱:</label>
                                            <?php if($GLOBALS['lock']==0): ?><input class="form__input" type="text" name="mail" value="<?php echo $mymail; ?>"/><?php else: ?>
											<input name="mail" type="text" class="form__input" value="<?php
//1.字符串截取法
$new_tel1 = substr($mymail, 0, 3).'****'.substr($mymail, 7);
echo $new_tel1;
?>" <?php if($GLOBALS['lock']==1): ?> readonly  unselectable="on"<?php endif; ?>> <?php endif; ?>
										</div>
									</div>

							
							        <?php if($GLOBALS['lock']==0): ?>
									<div class="col-12">
                                        <input name="do" type="hidden" value="profile">
										<button class="form__btn" type="submit" name="dosubmit"><span>确定</span></button>
									</div>
                                    <?php endif; ?>
                                  
								</div>
							</form>
							<!-- end form --> 
							
                
                      
                            <?php if($GLOBALS['lock']==0): ?>  
                         
                           <br>
                       
                           <!-- form -->
                              
							    <form action="<?php $security->index('/action/users-profile'); ?>" method="post"  class="input-form form" enctype="application/x-www-form-urlencoded" >
								<div class="row">
									<div class="col-12">
										<h2 class="form__title">修改密码</h2>
									</div>
                                    
                                    <div class="col-12 col-lg-6">
										<div class="form__group">
											<label  class="form__label">密码：</label>
											<input type="text" name="password" class="form__input" >
										</div>
									</div>

									<div class="col-12 col-lg-6">
										<div class="form__group">
											<label  class="form__label">重复密码:</label>
											<input class="form__input" type="text" name="confirm">
										</div>
									</div>			


									<div class="col-12">
                                        <input name="do" type="hidden" value="password">
										<button class="form__btn" type="submit" name="dosubmit" ><span>确定</span></button>
									</div>
                                    
								</div>
							</form>
							<!-- end form -->
                      
                      <?php endif; ?>    
                             


                      
                      </div>
					<!-- end post -->
                      
                    </div>


					<div class="tab-pane fade" id="tab-2" role="tabpanel" aria-labelledby="tab-2">
							
							
					<!-- post -->
<div class="faq seoxue">
<div class="row">  
  
                         <div class="col-12">
								<div class="faq__box">
									<h3>历史行为记录</h3>
									<ul class="web_lis">                             
                                     <?php paylist($myuid); ?>   
									</ul>
								</div>
							</div>

</div>
</div>
					<!-- end post -->	
							

                    <!--评论-->
                      <div class="main__box ">
                        <h2 class="form__title">近期评论</h2>
                      <?php
global $AuthorCommentId;//全局作者id
$AuthorCommentId=$myuid;//获取作者id
?>
                      <?php $this->widget('Widget_Post_AuthorComment@index','pageSize=15')->to($AuthorComment); ?>
                      <?php if ($AuthorComment->have()): ?>  
                      <?php while($AuthorComment->next()): ?>
                      <div class="post__comment" id="rctrly">
<a href="<?php $AuthorComment->permalink() ?>" class="post__comment-img">
<img src="<?php $email=$AuthorComment->mail; $imgUrl = getGravatar($email);echo ''.$imgUrl.''; ?>" alt="">
</a>
<div class="post__comment-title">
<h5><?php $AuthorComment->author(); ?></h5>
<p><?php $AuthorComment->dateWord(); ?></p>
</div>
<div class="post__comment-text"><?php $AuthorComment->content();?></div>
</div>
                      <?php endwhile; ?>
                      <?php else: ?>
                      <div class="allcomment-empy">暂无评论</div>
                      <?php endif; ?>
                        
                      </div>
                      <!--评论-->  
                      
							
					</div>

						<div class="tab-pane fade" id="tab-3" role="tabpanel" aria-labelledby="tab-3">
                          
                           <div class="main__box">
								<h3 class="main__box-title">网站公告</h3>
								<p class="main__box-text"><?php $this->options->webgong(); ?></p>
								
								
								
							</div>     
							
							
							
							
							
						</div>
                      
                      
                      
                     </div>

					 <!-- end big -->
              </div>
              
              
              
          </div>
		</div>
	</main>
    <div class="typecho-login" style="display: none;"></div>
	<!-- end main content -->


<!-- footer -->
<?php $this->need('footer.php'); ?>
<!-- end footer -->
<link rel="stylesheet" href="<?php $this->options->themeUrl('css/popup.css'); ?>"> 
<?php

include __ADMIN_DIR__ . '/common-js.php';
?>
