<?php

/**
* 登录页面
*
* @package custom
*/

include 'lib/common.php';

if (!defined('__TYPECHO_ROOT_DIR__')) exit;
 $this->need('header.php');
 ?>



<div class="sign">
<div class="container">
<div class="row">
<div class="col-12">
<div class="sign__content">


<?php if($this->user->hasLogin()): ?>
<script language="javascript" type="text/javascript">
window.location.href='<?php $this->options->siteUrl(); ?>';
</script>  
<?php endif; ?>


<div class="typecho-login" style="display: none;"></div>
<form action="<?php $this->options->loginAction()?>" method="post" name="login" rold="form" class="sign__form">
<input type="hidden" name="referer" value="<?php $this->options->siteUrl(); ?>">
<a href="<?php $this->options->siteUrl(); ?>" class="sign__logo">
<img src="<?php $this->options->logoUrl();?>" alt="">
</a>
<div class="sign__group">
<input type="text" class="sign__input" name="name" autocomplete="username" placeholder="请输入邮箱/账号" required>
</div>
<div class="sign__group">
<input type="password" class="sign__input" name="password" autocomplete="current-password" placeholder="请输入密码" required/>
</div>
<button class="sign__btn" type="submit"><span>登 录</span></button>
<span class="sign__text">注册新账号? <a href="<?php $this->options->signup(); ?>">注册</a> or  <?php  echo '<a href="' . Typecho_Common::url('Deng/forgot', $options->index) . '">' . '忘记密码' . '</a>' ;?></span> 

</form>                        
</div>
</div>
</div>
</div>
</div>



<!-- footer -->
<?php $this->need('footer.php'); ?>
<!-- end footer -->


<?php
echo '<link rel="stylesheet" href="' . Typecho_Common::url('style.css?v=' . $suffixVersion, $options->adminStaticUrl('css')) . '">';
include __ADMIN_DIR__ . '/common-js.php';
?>
