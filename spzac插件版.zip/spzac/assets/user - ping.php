<div class="col-12 col-md-5 col-lg-4 col-xl-3 fixsidenav ">
<div class="sidebox fixside s_ping" >
<h4 class="sidebox__title">最新评论</h4>
<i class="bg-primary"></i>
<div class="sidebox__content" id="rctrly">
<?php $this->widget('Widget_Comments_Recent','ignoreAuthor=false&pageSize=5')->to($comments); ?>
<?php if($comments->have()):?>  
<?php while($comments->next()): ?>
<div class="post__comment commentping">
<a href="<?php $comments->permalink(); ?>" class="post__comment-img">
<img src="<?php $email=$comments->mail; $imgUrl = getGravatar($email);echo ''.$imgUrl.''; ?>" alt="<?php $comments->author(); ?>">
</a>
<div class="post__comment-title">
<h5><a href="<?php $comments->permalink(); ?>" class="coment_link"><?php $comments->author(); ?></a>
<?php if ($comments->authorId != '0'):  ?>
<img src="/usr/themes/spzac/img/authen.svg" title="注册用户" class="s_authen">
<?php endif; ?>   
</h5>
<p><?php $comments->dateWord(); ?></p><?php on_comment($comments->coid);?>
</div>

<div class="post__comment-text" ><?php $cos=($comments->content); echo $cos;?></div>
</div>
<?php endwhile; ?> 
<?php else:?>
<p class="listnone">...看起来这里没有任何东西...</p>
<?php endif?>  
</div>

</div>

</div>