<!--vip会员-->
<div class="header__dropdown">
    <div class="header-box">
      <div class="refresh-header-top">
        <div class="header-top">
          <a class="user-names" href="<?php $this->options->siteUrl(); ?><?php if ($this->options->rewrite==0): ?>index.php/<?php endif; ?>author/<?php $this->user->uid(); ?>"><?php $email=$this->user->mail; $imgUrl = getGravatar($email);echo '<img src="'.$imgUrl.'">'; ?></a>
           <div class="">
              <span>
                <a class="user-names" href="<?php $this->options->siteUrl(); ?><?php if ($this->options->rewrite==0): ?>index.php/<?php endif; ?>author/<?php $this->user->uid(); ?>"><?php $this->user->screenName(); ?></a>
                <i class="wp wp-VIP"> 会员:<?php echo ueretime($this->user->uid); ?> </i>
               
             </span>
              <p>注册会员，享受下载全站资源特权。</p>
            </div>
            <?php $currGroup = get_object_vars($this->user) ['row']['group'];if ($currGroup == "administrator"): ?>
            <a href="<?php $this->options->adminUrl(); ?>options-theme.php" class="logout">后台管理</a>
            <?php else: ?>
            <a href="<?php $this->options->logoutUrl(); ?>" class="logout">退出</a>
            <?php endif;?>
          
          </div>
      </div>
      <div class="header-center">
        <div class="md-l">
          <span class="md-tit">交易信息</span>
          <span class="jinbi"><i></i>账号ID：<?php echo $this->user->uid(); ?></span>
          <span class="dou" ><i></i>订单记录：<?php echo payfees($this->user->uid); ?> 单</span> 
		  <span class="dou" ><i></i>消费金额：<?php echo payjiage($this->user->uid); ?> 元</span>    
        </div>
        <div class="md-r">
          <span class="md-tit">个人信息</span>
          <span class="jinbi"><i></i><?php $this->user->mail(); ?></span>
		   <span class="jinbi"><i></i>账号年龄：<?php echo reg_login($this->user->uid); ?> 天</span>
          <span class="dou" title="评论次数：<?php plium($this->user->uid);?>"><i></i>评论次数：<?php plium($this->user->uid);?> 次</span>           
        </div>
  </div>      

  </div>
  </div>
