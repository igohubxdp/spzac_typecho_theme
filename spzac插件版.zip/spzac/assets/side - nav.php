<div class="user__btns">
<a href="" class="user__btn user__btn--blue"><span>功能定制</span></a>
<a href="" class="user__btn user__btn--orange"><span>智能客服</span></a>
</div>