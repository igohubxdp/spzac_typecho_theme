document.write('<div class="fixed-sidebar" style="margin-left: -430px;">');
document.write('<div class="panel-set"><h3 class="panel-title">主题设置<small>Spimes</small></h3></div>');
document.write('<ul id="menu-items" class="menu">');
document.write('<li id="menu-item" class="item-0 "><a href="#div-1" class="link-0"><span><i class="icon iconfont icon-ic_password_line"></i> 常规设置 Info </span></a></li>');
document.write('<li id="menu-item" class="item-0 "><a href="#div-2" class="link-0"><span><i class="icon iconfont icon-ic_password_line"></i> 用户中心 Uer </span></a></li>');
document.write('<li id="menu-item" class="item-0 "><a href="#div-3" class="link-0"><span><i class="icon iconfont icon-ic_password_line"></i> 首页设置 Index </span></a></li>');
document.write('<li id="menu-item" class="item-0 "><a href="#div-4" class="link-0"><span><i class="icon iconfont icon-ic_password_line"></i>  广告设置 Advert </span></a></li>');
document.write('<li id="menu-item" class="item-0 "><a href="#div-5" class="link-0"><span><i class="icon iconfont icon-ic_password_line"></i> 风格样式 Style</span></a></li>');
document.write('<li id="menu-item" class="item-0 "><a href="#div-6" class="link-0"><span><i class="icon iconfont icon-ic_password_line"></i> 页脚设置 Foot</span></a></li>');

document.write('<li id="menu-item" class="item-0 "><a href="#typecho-option-item--30" class="link-0 ss"><span><i class="icon iconfont icon-anquan"></i> 保存设置 Save</span></a></li>');
document.write('</ul></div>');
document.write('<a href="#" id="scroll-to-top" class=""><span class="icon iconfont icon-ic_arrow_up"></span></a>');


$(document).ready(function() { $('a.link-0').click(function() { $('html, body').animate({ scrollTop: $($(this).attr('href')).offset().top+-60+'px' }, { duration: 500, easing: 'swing' }); return false; }); }); $(function(){ $('a.link-0').click(function (e) {  $('a.link-0').removeClass('active'); $(this).addClass('active'); }); });

// Run when the DOM ready
jQuery( function ( $ ) {

	var clickEvent = 'ontouchstart' in window ? 'touchstart' : 'click';

	/**
	 * Scroll to top
	 */
	function scrollToTop() {
		var $window = $( window ),
			$button = $( '#scroll-to-top' );
		$window.scroll( function () {
			$button[$window.scrollTop() > 100 ? 'removeClass' : 'addClass']( 'hidden' );
		} );
		$button.on( clickEvent, function ( e ) {
			e.preventDefault();
			$( 'body, html' ).animate( {
				scrollTop: 0
			}, 500 );
		} );
	}

	scrollToTop();
} );



 $('.current').after('<li><a href="/usr/themes/spzac/ext/danmu/admin"><i class="icon iconfont icon-icon-test15"></i> 播放器设置</a></li>');

