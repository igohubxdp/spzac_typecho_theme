<div class="col-12 col-md-5 col-lg-4 col-xl-3 fixsidenav">

                    <?php if ($this->is('post')): ?>
                    <!-- user -->
					<div class="sidebox user">
						<div class="user__head  bg_color">
							<div class="user__img">
								<img src="<?php $this->options->blogme(); ?>" alt="<?php $this->options->title() ?>">
							</div>
						</div>
						<div class="user__title">
							<h2><?php $this->options->title() ?></h2>
							<p><?php $this->options->description() ?></p>
						</div>						
                        <?php $this->need('assets/side - nav.php'); ?>
						<div class="sidebox__content">

                         <?php 
$slidenum = $this->options->tipid;
$hang = explode(",", $slidenum);
$n=count($hang);
$html="";
for($i=0;$i<$n;$i++){
$this->widget('Widget_Archive@kans'.$i, 'pageSize=1&type=post', 'cid='.$hang[$i])->to($ji);
if($i==0){$no=" sx_no";}else{$no="";}
$created = date('m-d', $ji->created);
$html=$html.' <div class="sidebox__job"><div class="sidebox__job-title"><a href="'.$ji->permalink.'">'.$ji->title.'</a><span><i class="icon iconfont icon-ic_message_line"></i></span></div></div>';
}
echo $html;
?>  
                          
</div>
						<div class="sidebox__more">网站简介</div>
					</div>
					<!-- end user -->
					<?php endif; ?> 

					<!-- sidebox -->
					<div class="sidebox sidebox--desk">
						<h4 class="sidebox__title">热门文章</h4>
                        <i class="bg-primary"></i>
						<div class="sidebox__content">
                            <?php theMostViewed(); ?>							
						</div>
						<a href="#" class="sidebox__more">View more</a>
					</div>
					<!-- end sidebox -->

			
                    <div class="sidebox sidebox__ad"><?php $this->options->adside(); ?></div>

                    
<!-- ping -->
<?php if ($this->is('index')): ?>
  
		<!-- sidebox -->
					<div class="sidebox sidebox--desk">
						<h4 class="sidebox__title">热评文章</h4>
                        <i class="bg-primary"></i>
						<div class="sidebox__content">
						    <?php getHotPosts('8');?>
						
						</div>
						<a href="#" class="sidebox__more">View more</a>
					</div>
					<!-- end sidebox -->

  
<?php else: ?>              
<div class="sidebox fixside s_ping">
<h4 class="sidebox__title">最新评论</h4>
<i class="bg-primary"></i>
<div class="sidebox__content" id="rctrly">

<?php $this->widget('Widget_Comments_Recent','ignoreAuthor=false&pageSize=5')->to($comments); ?>
<?php while($comments->next()): ?>
<div class="post__comment commentping">
<a href="<?php $comments->permalink(); ?>" class="post__comment-img">
<img src="<?php $email=$comments->mail; $imgUrl = getGravatar($email);echo ''.$imgUrl.''; ?>" alt="">
</a>
<div class="post__comment-title">
<h5><a href="<?php $comments->permalink(); ?>" class="coment_link"><?php $comments->author(); ?></a>
<?php if ($comments->authorId != '0'):  ?>
<img src="/usr/themes/spzac/img/authen.svg" title="注册用户" class="s_authen">
<?php endif; ?> 
</h5>
<p><?php $comments->dateWord(); ?></p><?php on_comment($comments->coid);?>
</div>
<div class="post__comment-text" ><?php $cos=($comments->content); echo $cos;?></div>
</div>
<?php endwhile; ?> 

</div>
<a href="#" class="sidebox__more">View more</a>
</div>
<?php endif; ?>     
<!-- end ping -->

				</div>

