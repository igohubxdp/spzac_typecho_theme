<?php

/**
* 付费功能表单
*
* @package custom
*/

if (!defined('__TYPECHO_ROOT_DIR__')) exit;
$this->need('header.php');
?>

	<!-- main content -->
	<main class="main main--breadcrumb">
		<!-- breadcrumb -->
		<?php $this->need('assets/post - link.php'); ?>
		<!-- end breadcrumb -->

		<div class="container">
			<div class="row neipage">
				<!-- header -->
	            <?php $this->need('user - sider.php'); ?>
	            <!-- end header -->

				<div class="col-12 col-md-7 col-lg-8 col-xl-9">
                  
<!--幻灯片-->
<div class="post post-ad"><img src="<?php $this->options->themeUrl('img/webcad.png'); ?>"></div>
<!--幻灯片-->
 

               
<!--打赏支付-->
<?php $this->need('assets/get-vip.php'); ?>
<!--打赏支付-->      

                  
                 
                  
				
				</div>
			</div>
		</div>
	</main>
	<!-- end main content -->

	<!-- footer -->
	<?php $this->need('footer.php'); ?>
	<!-- end footer -->
