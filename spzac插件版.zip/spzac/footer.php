<footer class="footer">
		<div class="container">
			<div class="row">
				<div class="col-12">
					<div class="footer__content">
						<a href="<?php $this->options->siteUrl(); ?>" class="footer__logo">
							<img class="scrollLoading" data-url="<?php $this->options->footlogo(); ?>" src="<?php $this->options->footlogo(); ?>" alt="<?php $this->options->title() ?>">
						</a>                       
						<span class="footer__copyright"><?php if($this->options->footnav){$this->options->footnav();} ?> 页面执行：<?php echo timer_stop();?></span>
						<nav class="footer__nav">
							<a href="">栏目1</a>							
							<a href="">栏目2</a>
						</nav>
						<button class="footer__back" type="button">
							<i class="icon iconfont icon-ic_arrow_up"></i>
						</button>
					</div>
				</div>
			</div>
		</div>
	</footer>

    <div class="back-to-top cd-top faa-float animated" ></div>


<!-- JS -->
	
	<script src="<?php $this->options->themeUrl('js/bootstrap.bundle.min.js'); ?>"></script> 
	<script src="<?php $this->options->themeUrl('js/main.js'); ?>"></script>
    <script src="<?php $this->options->themeUrl('js/i.js'); ?>"></script>  
    

<?php $this->options->zztj(); ?>
<?php if($this->options->foothtml){$this->options->foothtml();} ?>

<?php if ($this->options->themecompress == '1'):?>
<?php error_reporting(0); $html_source = ob_get_contents(); ob_clean(); print compressHtml($html_source); ob_end_flush(); ?>
<?php endif; ?>
<script src="<?php $this->options->themeUrl('js/instantpage-5.1.0.js'); ?>"></script>
<?php if($this->is('index') && $this->_currentPage == 1): ?>
<script src="<?php $this->options->themeUrl('js/swiper.min.js'); ?>"></script>
<script>
    var swiper = new Swiper('.swiper-container', {
        pagination: '.swiper-pagination',
        nextButton: '.swiper-button-next',
        prevButton: '.swiper-button-prev',
        slidesPerView: 1,
        paginationClickable: true,
        spaceBetween: 30,
        loop: true
    });
    </script>
 <?php endif; ?>
<?php $this->footer(); ?>
<?php if ( $this->is('post') && $this->fields->payview ) : ?>
 <script src="<?php $this->options->themeUrl('js/getcon.js'); ?>"></script>
<?php endif; ?>
 <?php $this->need('lib/right-user.php'); ?>
 <script>$('iframe').addClass('ifr_sl');</script>
</body>
</html>