<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;
 $this->need('header.php');
 ?>

	<!-- main content -->
	<main class="main main--breadcrumb">
		<!-- breadcrumb -->
		<?php $this->need('assets/post - link.php'); ?>
		<!-- end breadcrumb -->
		<div class="container">
			<div class="row">
				<div class="col-12 col-md-7 col-lg-8 col-xl-9">
                  
                  <!--payview-->
                  <?php if ($this->fields->payview): ?>                 
                  <div class="faq seoxue">
								<div class="faq__box">
								<h3>课程目录</h3>
                                <!--付费样式s-->
                                <div class="pay_post">
                                <div class="post__description"><div class="post__img"><a href="<?php $this->permalink(); ?>"><img class="post__img" src="<?php $this->fields->img(); ?>"></a> <p><?php $this->excerpt(160, '...');?></p> 
                                </div> </div>                               
                                <div>
                                <div style="padding: 10px; background: #f0f4f5; font-size: 13px;font-weight: 400; border-radius: 6px; margin-bottom: 10px;"> 直接阅读 </div>  
                                </div>
                             
                                </div>
                                <!--付费样式e-->
								<ul class="web_lis" style="border-top: 1px solid rgba(133,153,171,0.2); padding-top: 20px;">                             
                                <?php payview($this->fields->payview,$this->cid); ?>
								</ul>
								</div>
							</div>
                  <?php endif; ?>
                  <!--payview-->
                  
                  <?php if ($this->fields->videourl): ?><div class="videop">
      <?php $this->need('ext/danmu/post - dmplay.php'); ?>	</div>
      <?php endif; ?>  
                  
					<!-- post -->
<?php if ($this->options->txtadimg): ?>
<div class="post post-ad"><?php $this->options->txtadimg(); ?></div>
<?php endif; ?>
					<div class="post c_con" id="fu_con">
					<div class="post__head c_head">
			
				    <h2 class="post__title f_shadow" id="post_tit"><?php $this->title(); ?><?php if($this->user->hasLogin()):?><?php $currGroup = get_object_vars($this->user) ['row']['group'];if ($currGroup == "administrator"): ?> 					
					<a href="<?php $this->options->adminUrl(); ?>write-post.php?cid=<?php echo $this->cid;?>" class="category-link"  target="_blank"><?php _e( '[编辑]' ); ?></a><?php endif;?><?php endif;?></h2>
                    <div class="reward_list"><div class="reward_clusr">  <?php clusr($this->cid); ?>   </div></div>
                    </div>         

                      
                      
                <div class="post__description conts" id="post_ttx"> 
                <?php if ($this->options->cdnopen == '0'):?>
				<?php $str=$this->content; echo costcn($this->cid,$this->remember('mail',true),$str,$this->user->hasLogin()); ?>
				<?php else : ?>
				<?php $str = str_replace($this->options->cdnurla,$this->options->cdnurlb,$this->content); echo costcn($this->cid,$this->remember('mail',true),$str,$this->user->hasLogin());  ?>	
				<?php endif; ?> 
						</div>
                       
				<div class="Copyrightnew">文章由官网发布，如若转载，请注明出处：<?php $this->permalink() ?></div>                      
                         <div class="downmoi"></div>
						<div class="post__tags">
							<?php $this->tags(' ', true, ''); ?>
						</div>
						<div class="post__stats">
							<div>								
								<a class="post__comments" data-toggle="collapse" href="#collapse3" role="button" aria-expanded="false" aria-controls="collapse3"><i class="icon iconfont icon-ic_talk_line"></i> <span><?php $this->commentsNum('0 评论', '1 条评论', '%d 条评论'); ?></span></a>
							</div>
							<div class="post__views">
								<i class="icon iconfont icon-ic_visible"></i> <span><?php Postviews($this); ?></span>
							</div>
						</div>
					</div>
                  

                    
                  
                    
					<!-- end post -->
                    <?php if ($this->options->txtaddown): ?><div class="post post-ad"><?php $this->options->txtaddown(); ?></div><?php endif; ?>
					<!-- comments --> 
					<h3 class="main__title"><?php _e('发表评论'); ?></h3>
                    <?php $this->need('comments.php'); ?>
					<!-- end comments -->
					<?php $this->need('assets/post - more.php'); ?>
				 </div>
                 <?php if ($this->fields->down||$this->fields->downb): ?>
				 <?php $this->need('down - sider.php'); ?>
                 <?php else: ?>
                 <?php if (onpayost($this->cid)=='1'): ?>
                 <?php $this->need('down - sider.php'); ?>
				 <?php else: ?>
                 <?php $this->need('info - sider.php'); ?>
                 <?php endif; ?><?php endif; ?>
			</div>
		</div>
	</main>
	<!-- end main content -->
	<!-- footer -->
	<?php $this->need('footer.php'); ?>
	<!-- end footer -->

