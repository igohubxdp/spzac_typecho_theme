
    <!-- Swiper -->
<div class="col-md-12 Swiper_bl hidden-xs">
    <div class="swiper-container ">
        <div class="swiper-wrapper">         
		<?php hpianinfo(); ?>           
        </div>
        <!-- Add Pagination -->
        <div class="swiper-pagination"></div>
        <!-- Add Arrows -->
        <div class="swiper-button-next"></div>
        <div class="swiper-button-prev"></div>
    </div>
 </div>  

    <!-- Swiper JS -->

