<?php
/**
 * 用于作品展示、资源下载，行业垂直性网站、个人博客，简洁大气、优化SEO、多功能配置。为广大开发者/设计师等内容创作者提供一个原创内容发布，下载的系统平台
 *
 * @package Spzac Theme
 * @author Vv
 * @version 正式版
 * @link https://www.dpaoz.com/
 */

if (!defined('__TYPECHO_ROOT_DIR__')) exit;
 $this->need('header.php');


/** 文章置顶 */
$sticky = $this->options->zhiduid; //置顶的文章cid，按照排序输入, 请以半角逗号或空格分隔
if($sticky && $this->is('index') || $this->is('front')){
    $sticky_cids = explode(',', strtr($sticky, ' ', ','));//分割文本 
    $sticky_html = "<span class='badge arc_v5'>置顶</span>"; //置顶标题的 html
    $db = Typecho_Db::get();
    $pageSize = $this->options->pageSize;
    $select1 = $this->select()->where('type = ?', 'post');
    $select2 = $this->select()->where('type = ? && status = ? && created < ?', 'post','publish',time());
    //清空原有文章的列队
    $this->row = [];
    $this->stack = [];
    $this->length = 0;
    $order = '';
    foreach($sticky_cids as $i => $cid) {
        if($i == 0) $select1->where('cid = ?', $cid);
        else $select1->orWhere('cid = ?', $cid);
        $order .= " when $cid then $i";
        $select2->where('table.contents.cid != ?', $cid); //避免重复
    }
    if ($order) $select1->order(null,"(case cid$order end)"); //置顶文章的顺序 按 $sticky 中 文章ID顺序
    if ($this->_currentPage == 1) foreach($db->fetchAll($select1) as $sticky_post){ //首页第一页才显示
        $sticky_post['sticky'] = $sticky_html;
        $this->push($sticky_post); //压入列队
    }
$uid = $this->user->uid; //登录时，显示用户各自的私密文章
    if($uid) $select2->orWhere('authorId = ? && status = ?',$uid,'private');
    $sticky_posts = $db->fetchAll($select2->order('table.contents.created', Typecho_Db::SORT_DESC)->page($this->_currentPage, $this->parameter->pageSize));
    foreach($sticky_posts as $sticky_post) $this->push($sticky_post); //压入列队
    $this->setTotal($this->getTotal()-count($sticky_cids)); //置顶文章不计算在所有文章内
}


 ?>


	<!-- main content -->
	<main class="main">
		<div class="container">
			<div class="row">
				<!-- header -->
	            <?php $this->need('user - sider.php'); ?>
	            <!-- end header -->
 <?php if($this->is('index') && $this->_currentPage == 1): ?>
<!-- swiper -->
<div class="col-12 col-md-7 col-lg-8 col-xl-9 index_fx">
  
<!--幻灯片-->
<?php $this->need('index - hpian.php'); ?>
<!--幻灯片-->
  
  
  
<div class="row pagecontent">						

<?php 
$lunbotop = $this->options->imghdp;
$hang = explode(",", $lunbotop);
$n=count($hang);
$html="";
$j=0;                      
for($i=0;$i<$n;$i++){
$j++;
$this->widget('Widget_Archive@lunbotop'.$i, 'pageSize=1&type=post', 'cid='.$hang[$i])->to($jis);

$str = $jis->fields->img;

$html=$html.'<div class="col-12 col-sm-6 col-md-12 col-lg-6 col-xl-4 pagepost col-lv">
<div class="profile">
<div class="profile__logo">
<a href="'.$jis->permalink.'"><img src="'.$str.'" alt=""><i class="mask"></i></a>
</div>
<div class="profile__wrap">
<h2 class="profile__title"><a href="'.$jis->permalink.'">'.$jis->title.'</a></h2>
</div>
</div>
<div class="top-num top-'.$j.' fixsidenav"><span><i> NO.'.$j.'</i></span></div>
</div>';

}
echo $html;
                      
?>
</div>
</div>
<!-- end swiper -->
<?php endif; ?>


                 <?php if($this->is('index') && $this->_currentPage == 1): ?>
                <!-- user -ping -->
                <?php $this->need('assets/user - ping.php'); ?>
				<!-- end user -ping -->
                <?php endif; ?>

				<div class="col-12 col-md-7 col-lg-8 col-xl-6">

                   <!-- view big -->
	    
                   <ul class="nav nav-tabs main__nav" id="main__nav" role="tablist">
						<li class="nav-item">
							<a class="nav-link active" id="btnon" data-toggle="tab" href="#tab-1" role="tab" aria-controls="tab-1" aria-selected="false">最新文章</a>
						</li>

						<li class="nav-item">
							<a class="nav-link" id="btnoff" data-toggle="tab" href="#tab-2" role="tab" aria-controls="tab-2" aria-selected="true">关于我们</a>
						</li>

						<li class="nav-item">
							<a class="nav-link" id="btnofff" data-toggle="tab" href="#tab-3" role="tab" aria-controls="tab-3" aria-selected="false">网站公告</a>
						</li>                      
					</ul>
                   

                    <div class="tab-content">
					<div class="tab-pane fade show active pagecontent" id="tab-1" role="tabpanel" aria-labelledby="tab-1">
					<!-- post -->
                      
                    <div class="faq">
						<div class="row">                           
                           <div class="col-12">
								<div class="faq__box">
									<h3>最新动态</h3>
									<ul class="index_lis web_lis">
                                        <?php $this->widget('Widget_Archive@xuec1', 'pageSize=14&type=category', 'mid='.$this->options->inlist)->to($categoryPosts); ?>
                                        <?php while($categoryPosts->next()): ?>
										<li class="l_ase"><a href="<?php $categoryPosts->permalink(); ?>"><?php listdeng($categoryPosts);?><?php $categoryPosts->title(); ?></a>
                                        <div class="post__views" style="float: right;"><span class="i_fuei"><?php Postviews($categoryPosts); ?> 阅读</span></div>
                                        </li>
                                        <?php endwhile; ?>	
									</ul>
								</div>
							</div>                          
                          </div>
						</div> 
                      
					<?php $this->need('post - list.php'); ?>
					<!-- end post -->
                    </div>


					<div class="tab-pane fade" id="tab-2" role="tabpanel" aria-labelledby="tab-2">                      
							
					<div class="main__box">
					<h3 class="main__box-title">About</h3>

                    <?php $this->widget('Widget_Contents_Page_List')->to($pages); ?>
<?php while($pages->next()): ?>
<?php if ($pages->slug == $this->options->aboutme): ?>
<div class="main__box-text index_about"><?php $pages->content(); ?> ...</div>
<?php endif; ?>
<?php endwhile; ?>

								
					</div>				
                    </div>

						<div class="tab-pane fade" id="tab-3" role="tabpanel" aria-labelledby="tab-3">                                            
                                                                                               
                            <div class="main__box">                                                  
								<h3 class="main__box-title">网站公告</h3>
								<div class="sidebox__faq">
                                <p><?php $this->options->webgong(); ?></p>
                                </div>                                                         
							</div>                                                             
                                                                                               
						</div>
                     </div>

					 <!-- end big -->

					<!-- view more -->
					<?php $this->pageNav('<', '>', 1, '...', array('wrapTag' => 'div', 'wrapClass' => 'page-navigator ', 'itemTag' => 'li', 'textTag' => 'span', 'currentClass' => 'current', 'prevClass' => 'prev', 'nextClass' => 'nexts',)); ?>				
					<!-- end view more -->
                                                         
				</div>

				<?php $this->need('info - sider.php'); ?>
			</div>
		</div>
	</main>
	<!-- end main content -->

	<!-- footer -->
	<?php $this->need('footer.php'); ?>   
	<!-- end footer -->

<script>

$(document).ready(function() {
    $("#btnofff").click(function() {
		$(".page-navigator").hide();
	})
	$("#btnoff").click(function() {
		$(".page-navigator").hide();
	})
    $("#btnon").click(function() {
		$(".page-navigator").show();
	})                       
});

</script>  