<header class="header">
		<div class="container">
			<div class="row">
				<div class="col-7 col-md-9 col-lg-8 col-xl-10">
					<div class="header__content">
						<!-- header menu btn -->
						<button class="header__btn" type="button">
							<span></span>
							<span></span>
							<span></span>
						</button>
						<!-- end header menu btn -->
						<!-- header logo -->
						<a href="<?php $this->options->siteUrl(); ?>" class="header__logo">
						<img src="<?php $this->options->logoUrl();?>" alt="">
						</a>
						<!-- end header logo -->
						<!-- header nav -->
						<?php $this->need('assets/nav_comto.php'); ?>
						<!-- end header nav -->
						<!-- header search -->
						<form action="" class="header__search" method="get">
							<input class="header__search-input" type="text" placeholder="Search..." name="s">
							<button class="header__search-button" type="submit">
								<i class="icon iconfont icon-ic_search_line"></i>
							</button>
                            <i class="up-new"></i>
						</form>
						<!-- end header search -->
					</div>
				</div>
				<div class="col-5 col-md-3 col-lg-4 col-xl-2">
					<div class="header__content header__content--end">

						<!--公告s-->
                         <div class="header__notifications show">
<a class="dropdown-toggle header__notifications-btn header__notifications-btn--active" href="#" role="button" id="dropdownMenuNotifications" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
<i class="icon iconfont icon-ic_notice_line"></i>
</a>
<div class="dropdown-menu dropdown-menu-right header__dropdown-menu header__dropdown-menu--right header__dropdown-menu--ntf" aria-labelledby="dropdownMenuNotifications">   
<?php newones(1,5);?>
<a href="<?php $this->options->signin(); ?>" class="header__ntf-more">加入我们</a>
</div>
</div>
                        <!--公告e-->
                   
						
                        <?php if($this->user->hasLogin()): ?>
                       
						<div class="header__profile">
							<a class="dropdown-toggle header__profile-btn" href="#" role="button" id="dropdownMenuProfile" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
							<?php $email=$this->user->mail; $imgUrl = getGravatar($email);echo '<img src="'.$imgUrl.'" width="25px" height="25px" >'; ?>
							<span><?php $this->user->screenName(); ?></span>
							</a>
							<div class="dropdown-menu dropdown-menu-right header__dropdown-menu header__dropdown-menu--right aut_wl" aria-labelledby="dropdownMenuProfile">
							<?php $this->need('assets/author - nav.php'); ?>
							</div>
						</div>
                                         
                      <?php else: ?>

                      
                      <div class="header__profile"><div class=""><span><a class="signin" href="<?php $this->options->signin(); ?>">登录</a> / <a class="signin" href="<?php $this->options->signup(); ?>">注册</a></span></div></div>
                     

					  <?php endif; ?>
					</div>
				</div>
			</div>
		</div>
	</header>