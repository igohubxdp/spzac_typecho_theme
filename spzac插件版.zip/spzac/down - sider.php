<div class="col-12 col-md-5 col-lg-4 col-xl-3 fixsidenav">

                    <?php if ($this->is('post')): ?>
                    <!-- user -->
					<div class="user fixside downon">
						<div class="user__head  bg_color">
							<div class="user__img">
								<img src="<?php $this->options->blogme(); ?>" alt="<?php $this->options->title() ?>">
							</div>
						</div>
						
						<div class="user__title">							
							<p>版权申明：本素材由本站发布，用户购买后只有终端使用权，禁止转售和转载</p>
						</div>

						<!--免费下载-->
                        <?php if ($this->fields->down): ?>
						<div class="user__btns">
						<a href="<?php $this->fields->down(); ?>" class="user__btn user__btn--blue user__down"><span>免费下载</span></a>
						</div>
                        <?php endif;?>
                        <!--免费下载-->

                        <!--注册下载-->
                        <?php if($this->fields->downb): ?><?php if($this->user->hasLogin()): ?>						
                        <div class="user__btns">
						<a href="<?php $this->fields->downb(); ?>" class="user__btn user__btn--orange user__down" ><span>会员下载</span></a>
						</div>
                        <?php else: ?>
                        <div class="user__btns" id="autip">
						<a href="javascript:void(0);" class="user__btn user__btn--orange user__down" ><span>会员下载</span></a>						
						</div>
                        <?php endif;?><?php endif;?>
						<!--注册下载e-->
                        <?php if ($this->fields->sidedown!= '0'):?>       					
                        <nocompress>
                        <?php if (array_key_exists('TePass', Typecho_Plugin::export()['activated'])){echo TePass_Plugin::getTePass();} ?>
                        </nocompress>	
                        <?php else: ?>
                        <div class="sidebox__content">
                      
<?php 
$slidenum = $this->options->tipid;
$hang = explode(",", $slidenum);
$n=count($hang);
$html="";
for($i=0;$i<$n;$i++){
$this->widget('Widget_Archive@kans'.$i, 'pageSize=1&type=post', 'cid='.$hang[$i])->to($ji);
if($i==0){$no=" sx_no";}else{$no="";}
$created = date('m-d', $ji->created);
$html=$html.' <div class="sidebox__job"><div class="sidebox__job-title"><a href="'.$ji->permalink.'">'.$ji->title.'</a><span><i class="icon iconfont icon-ic_message_line"></i></span></div></div>';
}
echo $html;
?>               
                      
</div>
                        <?php endif; ?>

                        
                       
                      
					</div>
					<!-- end user -->
					<?php endif; ?> 
  
                   
  
</div>
