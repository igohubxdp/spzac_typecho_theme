<div class="fixed-sidebar right">
	<div class="fixed-sidebar-right sidebar--small" >
		<div class="mCustomScrollbar ps ps--theme_default ps--active-y" >
			<ul class="chat-users"></ul>
	</div>
	</div>
</div>
