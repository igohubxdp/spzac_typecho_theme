<?php

/**
 * config - menber.php
 * Author     : 小灯泡设计
 * Date       : 2020/4/3
 * Version    : 1.0
 * Description: 会员-积分配置
 **/
 



function get_logins($sum) {
 $db = Typecho_Db::get();
  $current = $db->fetchAll($db->select()->from('table.users')
   // ->page($currentPage, $pageSize)
   // ->where('group = ?', 'contributor') 
    ->where('uid <> ?', '1') //排除站长             
    ->limit($sum)                       
    ->order('activated', Typecho_Db::SORT_DESC));
    foreach($current as $line){   
    $gethml =  $gethml.'<li class="inline-items js-chat-open"><div class="author-thumb"><a href="'.Helper::options()->siteUrl.'author/'.$line['uid'].'"><img title="'.$line['name'].'-'.get_last_login($line['uid']).'" src="'.getGravatar($line['mail']).'" class="avatar"></a><span class="icon-status online"></span></div></li>';
   }
   return $gethml;
  
}

