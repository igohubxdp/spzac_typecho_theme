<div class="user__btns">
<a href="<?php $this->options->siteUrl(); ?>vipbuy.html" class="user__btn user__btn--blue"><span>功能定制</span></a>
<a href="<?php $this->options->siteUrl(); ?>aiwen.html" class="user__btn user__btn--orange"><span>智能客服</span></a>
</div>