<ul class="header__nav">
							<!-- dropdown -->
							<li class="header__nav-item">
								<a href="<?php $this->options->siteUrl(); ?>" class="header__nav-link"><?php _e('首页'); ?></a>
							</li>

                     


	<!-- dropdown -->
<?php $this->widget('Widget_Metas_Category_List')->to($categorys); ?>
<?php while($categorys->next()): ?>						
<?php if ($categorys->levels === 0): ?>
<?php $children = $categorys->getAllChildren($categorys->mid); ?>
<?php if (empty($children)) { ?>
 <li class="header__nav-item">	<a href="<?php $categorys->permalink(); ?>" class="header__nav-link"><?php $categorys->name(); ?></a></li>
<?php } else { ?>
<li class="header__nav-item"><a class="dropdown-toggle header__nav-link" href="#" role="button" id="dropdownMenuProjects" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><?php $categorys->name(); ?></a>
<ul class="dropdown-menu header__dropdown-menu" aria-labelledby="dropdownMenuProjects">
<li><a href="<?php $categorys->permalink(); ?>"><?php $categorys->name(); ?></a></li>
<?php foreach ($children as $mid) { ?>
<?php $child = $categorys->getCategory($mid); ?>
<li><a href="<?php echo $child['permalink'] ?>"><?php echo $child['name']; ?></a></li>
<?php } ?>
</ul></li>
<?php } ?>
<?php endif; ?>
<?php endwhile; ?>
<!-- end dropdown -->


							<!-- end dropdown -->
                           
				
</ul>