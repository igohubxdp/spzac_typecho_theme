<?php 
header('Content-Type: text/html;charset=utf-8');

$QQ=$_POST["qq"];
if($QQ!=''){
  
$urlPre='http://r.qzone.qq.com/fcg-bin/cgi_get_portrait.fcg?g_tk=1518561325&uins=';
$data=file_get_contents($urlPre.$QQ);
$data=iconv("GB2312","UTF-8",$data);
$pattern = '/portraitCallBack\((.*)\)/is';
preg_match($pattern,$data,$result);
$result=$result[1];
$nickname = json_decode($result, true)["$QQ"][6]; 

$geturl = 'http://ptlogin2.qq.com/getface?&imgtype=1&uin='.$QQ;
$qqurl = file_get_contents($geturl);
$str1 = explode('sdk&k=', $qqurl);
$str2 = explode('&t=', $str1[1]);
$k = $str2[0];
if(empty($k)){
$url = '/usr/themes/spzac/img/wu-user.png';
} 
else{ $url = 'https://q1.qlogo.cn/g?b=qq&k='.$k.'&s=100';} 

$aaa =  array('name'=>$nickname,'qqtx'=>$url);
$bbb  =json_encode($aaa);
echo $bbb;
  
}else{
echo "请输入qq号！";
}
?>