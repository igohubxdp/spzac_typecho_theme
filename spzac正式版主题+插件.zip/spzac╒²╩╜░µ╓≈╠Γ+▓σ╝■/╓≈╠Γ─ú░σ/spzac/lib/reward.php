<!-- form -->



<script type="text/javascript">
function show_confirm()
{
var r=confirm("已完成打赏，并确认提交？");
if (r==true)
  {
  alert("感谢打赏下单");
    return true; 
  }
else
  {
  alert("已取消");
    return false;
  }
}
</script>


                        <form action="" method="post" class="input-form form" name=forma onsubmit='return show_confirm();'>
                                <?php if(!$this->user->hasLogin()): ?>
							    <div class="comment-overlay">                           
                                  <div class="comment-overlay-login"><p>您必须<a href="<?php $this->options->signin(); ?>">登录</a>或<a href="<?php $this->options->signup(); ?>">注册</a>以后提交工单哦~</p></div>                                  
                                </div>
                                <?php endif; ?>
								<div class="row">
									<div class="col-12">
										<h2 class="form__title">提交工单</h2>
									</div>

									<div class="col-12 col-lg-3 pay_c">
										<div class="form__group">
											<img class="pay_img" src="<?php $this->options->zfbpay(); ?>">
										</div>
                                        <div class="form__group">
											<img class="pay_img" src="<?php $this->options->wxpay(); ?>">
										</div>
									</div>									

									<div class="col-12 col-lg-9 ">
										<div class="form__group">
                                          
                                          
<p class="main__box-text">更好的服务：通过QQ和我们自建工单的系统进行售前售后服务，最有效的解决用户实际问题。</p> <p class="main__box-text">更好的指导能让你使用无障碍、建站有自信。</p>  
<p class="main__box-text">你只需要用心做站</p>

                                          
											<label for="lastname" class="form__label">留言内容:(请不要恶意提交，违规者永久禁言)</label>
											<textarea name="content" id="text" class="form__textarea" ></textarea>
                                            <button class="form__btn" type="submit" name="dosubmit"><span>打赏下单</span></button>
                                           
										</div>
                                        <p class="main__box-text">如有疑问，更多问题</p>
                                      <p class="main__box-text">咨询在线客服</p>
									</div>
                                    
								</div>
							</form>


<?php
     
    //留言板的思路：1.先创建一个文件名，方便于存放写入的内容
    // 2.将表单中的内容赋值给一个变量
    //3.判断文件是否存在，将用户输入的值写进变量，打开文件的是时候注意选择对文件访问的操作
    //4.读取文件的内容,关闭文件    
    
    $filename = "reward.txt";//创建一个文件的名字     
    //如果用户提交了， 就写入文件， 按一定格式写入
    if(isset($_POST['dosubmit'])) {
    //字段的分隔使用||, 行的分隔使用[n]
      
      
    if($this->user->hasLogin()){
    $username = $this->user->screenName;
    $useruid = $this->user->uid;
    }
    else{
    $username ='游客';
    $userimg ='1234';
    }
    $content = $_POST['content'];  
      
    $dtime = date("Y-m-d H:i",time());  
      
    $mess = "姓名：{$username}，".$dtime."已打赏，留言内容：{$content}[n]";   
      
    $mess = trim($mess);  //清理空格  

    $mess = strip_tags($mess);   //过滤html标签  

    $mess = htmlspecialchars($mess);   //将字符内容转化为html实体  

    $mess = addslashes($mess);  //防止SQL注入 
  
    $teepay_Server = Helper::options()->plugin('Deng')->iyuukey;       
    file_get_contents('http://iyuu.cn/'. $teepay_Server .'.send?desp='.$mess.'&text='.urlencode('已有人打赏咯'));  
     
    writemessage($filename, $mess);//向文件写进内容     
    }     
    if(file_exists($filename)) {//判断文件 是否存在
    readmessage($filename);//读取文件的函数
    }
     
    function writemessage($filename, $mess) {
    $fp = fopen($filename, "a");//在尾部执行写的操作，且不删除原来的文件内容
    fwrite($fp, $mess);//写入文件     
    fclose($fp);//关闭文件     
    header('location:/');     
    }     
    function readmessage($filename) {
    $mess = file_get_contents($filename);
    $mess = rtrim($mess, "[n]");     
    $arrmess = explode("[n]", $mess);
     
   // foreach($arrmess as $m) {
   // list($username, $dt ,$title, $content) = explode("，", $m);
   // $time = date("Y-m-d H:i",$dt);
   // echo "<li>".$time."<br/> {$username} {$title} {$content}</li>";
   // }     
    }
     
    ?>