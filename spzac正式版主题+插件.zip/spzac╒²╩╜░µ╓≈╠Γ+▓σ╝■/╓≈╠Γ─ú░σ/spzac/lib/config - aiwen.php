<?php

/**
 * config - aiwen.php
 * Author     : 小灯泡设计
 * Date       : 2020.11.12
 * Version    : 1.0
 * Description: 小灯芯在线智能AI
 **/


// 入场分析用户，开场对话
function aiwen_begin($uid){ 
  
  if($uid){//判断是不是登录会员
      if(on_userid($uid)){ //是vip会员
        
           //查询购买过的主题，并且推荐可以付费定制新功能，和下一步的更新计划        
          
           $text = "你好，尊敬的vip会员，你之前购买过的主题版本目前更新到4.3，如有需要，可以进入到主题页面进行下载哦";
        }
        else{ //是普通会员
          
          //查询付款的订单和未付款的订单，付费如同会员推荐，未付款进行引导推荐
          
          $text = "你好，尊敬的xxx用户";
        }
  }
  else{ 
  
    //游客……边边去
  
  } //是游客  
  return $text; 
}

// 开场功能
function aiwen($data,$uid){  
  
  //是否保存记录s  --------
  if($uid!=1){
  $teepay_Server = 'IYUU3147T29ab2634eef29ae6e0dd77082d8506a766d843db';       
  file_get_contents('http://iyuu.cn/'. $teepay_Server .'.send?desp='.urlencode('用户id'.$uid.'发起对话：'.$data).'&text='.urlencode('有人咨询客服了'));  
  }  
  //是否保存记录e  --------
  
  if(strstr($data,'@')){ //指令搜索
    $data = str_replace(array("@"),"",$data);
    $text = aiwen_soso($data,10);    
    return $text;     
  }
  else if(strstr($data,'-')){ //指令执行
    $data = str_replace(array("-"),"",$data);
    $text = aiwen_plan($data,$uid);    
    return $text;    
  }
  else{  // 进入对话
    $text = aiwen_str($data);
    return $text; 
  }
  
}


// ********************************
// ************关键字处理**********
// ********************************
// 判断词库回答
function aiwen_str($data){
  
  $themewords = "spimes|spzac|typecho|ty|php|seo|wp|wordpress|dede|会员|联系|小灯芯|小程序|打赏|仿站";   //网站的基本关键字  
  
  if(preg_match("/^[a-zA-Z\s]+$/",$data)){    
    if(preg_match("/$themewords/i",$data)){ $i=false;} //属于基本关键字就返回false
    else{ $i=true; }    
  }
  
  if( $i|| is_numeric($data)){
    
  $text = aiwen_ennumwords();  //数字英文对话
    
  }
  //关键词优先处理
  else if(preg_match("/$themewords/i",$data)){
    
  $text = aiwen_themewords($data);  //网站设定关键字对话
     
  }
  else{
    
  $text = aiwen_cikuword($data);  //词库收尾对话
    
  }
  
  return $text; 
  
}
// ********************************
// ************关键字处理**********
// ********************************





// *********************************
// *****未匹配后的对话措施收尾******
// *********************************
function aiwen_cikuword($data){  
//词库判断 
  
  $fuckwords = "恶心|垃圾|去死|你妈|尼玛|逗比|逗逼|傻子|有病|骗子|黑商|傻逼";   //骂人的对话
  $hellowords = "你是|你好|在吗|您好|有人|出来|客服|来了|咨询|想问|有问题|吃饭";  //打招呼的对话
  $faqwords = "推荐主题|最新主题|热门主题";    //资讯内容的对话
  $pricewords = "多少钱|价格|费用|怎么买|怎么卖|购买|我要买|下载";//咨询价格的对话
  $updatewords = "升级|更新|覆盖|typecho升级|ty升级";//升级，更新对话
  $thankwords = "谢谢|多谢|感谢|感激|麻烦了|爱你";//感谢对话
  $zmzmzmwords = "怎么改|怎么设置|幻灯片|封面|不显示|错误|用不了|不能用";//怎么怎么怎么怎么之类的话语
    

  if(preg_match("/$fuckwords/i",$data)){  //骂人的对话
    
  $text = aiwen_fuckwords();
 
  }
  else if(preg_match("/$thankwords/i",$data)){  //感谢的话
    
  $text = aiwen__thankwords();
 
  }
  else if(preg_match("/$hellowords/i",$data)){  //打招呼的对话
    
  $text ="在的，你好，有什么可以帮到你的吗？";
 
  }
  else if(preg_match("/$pricewords/i",$data)){ //咨询价格的对话
    
  $text ="你好，主题的价格均在主题介绍页可以看到，购买流程需登录付款后就可以直接下载，版本功能介绍和更新下载都在主题介绍页哦~";
 
  }
  else if(preg_match("/$updatewords/i",$data)){ //升级更新对话
    
  $text ="你好，每个程序的主题更新都不一样，但是唯一需要注意的地方就是先记得备份哦<br/>
         Typecho主题升级比较麻烦，需要先删除旧文件夹，然后上传新文件夹<br/>
         每次新版本都有可能改变了主题的结构和文件，覆盖有可能会残留多余的文件数据……<br/>
         因此升级/更新的时候，只要主题文件夹名字没有改变，都可以随意折腾……毕竟也备份了……
         ";
 
  }
  else if(preg_match("/$zmzmzmwords/i",$data)){ //怎么怎么这怎么对话
    
  $text ="这……我这边也不是很清楚，你可以尝试以 @+关键字 获取相关的教程帮助哦，也可以在主题页下方留言咨询";
 
  }
  else if(preg_match("/$faqwords/i",$data)){  //资讯内容的对话
   
    $db = Typecho_Db::get();
    $result = $db->fetchAll($db->select()->from('table.contents')
        ->where('status = ?','publish')
        ->where('type = ?', 'post')
        ->where('created <= unix_timestamp(now())', 'post') //添加这一句避免未达到时间的文章提前曝光
        ->limit(5)
        ->order('commentsNum', Typecho_Db::SORT_DESC)
    );
    if($result){
        foreach($result as $val){            
            $val = Typecho_Widget::widget('Widget_Abstract_Contents')->push($val);
            $post_title = htmlspecialchars($val['title']);
            $permalink = $val['permalink'];           
			$text =$text.'<a href="' .$permalink. '">' .$post_title. '</a>' . $val['commentsNum'] . ' 评论<br/> '; 
        }
    }       
    
  }
  else{ 
  
   $text = $data."? 您表达的不是很清楚哦，请尝试换一个简洁的关键字提问，或者直接联系客服把~<br/>-------------------<br/>".aiwen_soso($data,5);//最后一道门口，开始多重搜搜 
      
  }
    
  //词库判断结束 

  
  return $text; 
  
  
 }




//***************************************指令函数行为**********************************************

//指令执行
function aiwen_plan($data,$uid){
  
  if($data == '打赏'){    
    $zfbpay = Helper::options()->zfbpay;
    $wxpay = Helper::options()->wxpay;    
    $text ='感谢你的支持，对您的感激千言万语也无法表达~~ <br/>打赏方式如下<br/><img src='.$zfbpay.' style="margin: 15px;width: 200px;"><img src='.$wxpay.' style="margin: 15px;width: 200px;">'; 
  }
  else if($data == '消费记录' ){
    if($uid){
      //开始查询会员的消费记录
      $db = Typecho_Db::get();
     
      $result = $db->fetchAll($db->select()->from('typecho_teepay_fees')
        ->where('feeuid = ?',$uid)
        ->where('feestatus=?', '1')                      
        ->limit(20)        
      );
       if($result){
        foreach($result as $val){  
            $post_cid = $val['feecid'];
            $text = "你好，你目前的消费记录：".payjiage($uid)."元<br/>-------------------<br/>你购买过……<br/>"; 
			$postval =  $db->fetchAll($db->select()->from('table.contents')->where('cid = ?',$post_cid));          
            foreach($postval as $vals){  
             $vals = Typecho_Widget::widget('Widget_Abstract_Contents')->push($vals);
			 $post_title = htmlspecialchars($vals['title']);
             $permalink = $vals['permalink'];
			 $text =$text.'<a href="' .$permalink. '">' .$post_title. ' </a><br/>';
			}
            }
                 }
	             else{
                 $text = "暂无消费";
	             }
     //查询结束      
    }
    else { $text = "很抱歉~没有查询到，只有会员才有消费记录呢~"; }
  }
  else{
     $text ='非法指令，无非识别'; 
  }
  return $text; 
}


// 搜索对话
function aiwen_soso($data,$limit){  
   
   $searchQuery = '%' . str_replace(' ', '%', $data) . '%'; 
   $db = Typecho_Db::get();
   $result = $db->fetchAll($db->select()->from('table.contents')
        ->where('status = ?','publish')
        ->where('type = ?', 'post')
        ->where('created <= unix_timestamp(now())', 'post') //添加这一句避免未达到时间的文章提前曝光
        ->where('table.contents.title LIKE ? ', $searchQuery)
        ->limit($limit)
        ->order('created', Typecho_Db::SORT_DESC)
    ); 
    if($result){
          $text = $text."匹配到如下文章，也许是你需要的<br/>"; //最后一道门卡 
          foreach($result as $val){            
            $val = Typecho_Widget::widget('Widget_Abstract_Contents')->push($val);
            $post_title = htmlspecialchars($val['title']);
            $permalink = $val['permalink'];           
			$text =$text.'<a href="' .$permalink. '">' .$post_title. '</a><br/> '; 
           }
    }//匹配文章标题
    else{
        
        $result = $db->fetchAll($db->select()->from('table.contents')
        ->where('status = ?','publish')
        ->where('type = ?', 'post')
        ->where('created <= unix_timestamp(now())', 'post') //添加这一句避免未达到时间的文章提前曝光
        ->where('table.contents.text LIKE ? ', $searchQuery)                                
        ->limit(5)
        ->order('created', Typecho_Db::SORT_DESC)
        ); 
       if($result){
          $text = $text."暂时无匹配到标题文章，推荐以下匹配内容的文章<br/>"; //匹配文章内容 
          foreach($result as $val){            
            $val = Typecho_Widget::widget('Widget_Abstract_Contents')->push($val);
            $post_title = htmlspecialchars($val['title']);
            $permalink = $val['permalink'];           
			$text =$text.'<a href="' .$permalink. '">' .$post_title. '</a><br/> '; 
           }
        }
        else{  $text = "暂无相关的文章信息哦~"; }
      
      
    }//匹配文章内容  
    return $text;   
}



//网站基本关键字的执行

function aiwen_themewords($data){
  
  $spimeswords = "spimes|spimes主题|spimes模板";   //spimes关键字
  if (preg_match("/$spimeswords/i",$data)){ 
    $text ="你好，让我为你详细介绍spimes主题把<br/>spimes是一套typecho程序主题模板，无授权无加密，目前售价150元<br/>-------------------<br/>目前版本：4.4版本<br/>-------------------<br/>直接购买：<a href='https://www.dpaoz.com/85'>https://www.dpaoz.com/85</a><br/>安装说明：<a href='https://www.dpaoz.com/306'>https://www.dpaoz.com/306</a><br/>主题ICO图标：<a href='https://www.dpaoz.com/iconcss'>https://www.dpaoz.com/iconcss</a><br/>配套小程序：<a href='https://www.dpaoz.com/760'>https://www.dpaoz.com/760</a>";
    //介绍完主题，然后匹配相关内容推荐
    $text = $text."<br/>-------------------<br/>".aiwen_soso($data,10);  
  }
  else if(strcasecmp($data, 'spzac') == 0){ 
    $text ="你好，让我为你详细介绍spzac主题把<br/>spzac是一套typecho程序主题模板，无授权无加密，目前售价120元<br/>-------------------<br/>
    正式版：主题+主题配置插件和teepay支付插件，独立会员用户中心.演示具体看官网
    <br/>
    插件版：主题+TePass插件售价（需要单独购买）
    <br/>-------------------<br/>
    目前版本：4.0版本<br/>-------------------<br/>直接购买：<a href='https://www.dpaoz.com/204'>https://www.dpaoz.com/204</a><br/>安装说明：<a href='https://www.dpaoz.com/762'>https://www.dpaoz.com/762</a><br/>主题ICO图标：<a href='https://www.dpaoz.com/icon-spzac'>https://www.dpaoz.com/icon-spzac</a>";
    //介绍完主题，然后匹配相关内容推荐
    $text = $text."<br/>-------------------<br/>".aiwen_soso($data,10); 
  }
   else if(strcasecmp($data, 'typecho') == 0){ 
    $text ="Typecho是一个由中国团队开发的开源跨平台博客程序。它基于PHP5构建,并支持多种操作系统(Linux,Unix,BSD,Windows)、 服务器(Apache,Lighttpd,IIS,Nginx)和数据库(Mysql,PostgreSQL,SQLite)。
    <br/>-------------------<br/>官网和下载地址：<a href='http://typecho.org/download'>http://typecho.org/download</a><br/>-------------------<br/>安装Typecho的过程和大多数博客程序没有什么不同，整个安装过程只需要你根据安装向导依次完成即可<br/>1，搭建服务器环境<br/>2，上传程序，填写相关数据库，管理员账户信息<br/>3，配置伪静态规则,简短url路径<br/>4，主题文件夹：themes，插件文件夹：plugins<br/>5，配置相关的主题参数<br/>-------------------<br/>
    优点：<br>
    Typecho很纯粹，就是为了写作而生的博客程序，更加小型、灵活真正适合博客需求的轻量级程序<br/>程序轻量高效，风格简洁，属于一张白纸写博客的极简程序<br>
    缺点：<br>程序扩展弱可发性不强，插件少，功能少。<br>
    大部分用户受不了：图片不能复制编辑，编辑器简洁不能丰富排版，插件少不能实现丰富功能<br/>-------------------<br/>因此在购买的时候，请大家了解清楚后，再决定是否付费";

    $text = $text."<br/>-------------------<br/>".aiwen_soso($data,10); 
  }
  else if(strcasecmp($data, '会员') == 0){ 
    $text ="你好，开通会员：( 299元/年会员 )，详情请联系站长";
   }
  else if(strcasecmp($data, '小程序') == 0){ 
    $text ="你好，暂时还在开发阶段哦";
  }
  else if(strcasecmp($data, '打赏') == 0){ 
    $zfbpay = Helper::options()->zfbpay;
    $wxpay = Helper::options()->wxpay;  
    $text ='感谢你的支持，对您的感激千言万语也无法表达~~ <br/>打赏方式如下<br/><img src='.$zfbpay.' style="margin: 15px;width: 200px;"><img src='.$wxpay.' style="margin: 15px;width: 200px;">'; 
  }
  else if(strcasecmp($data, '小灯芯') == 0){ 
    
    $text = aiwen_myself();    
      
  }
  else if(strcasecmp($data, '仿站') == 0){ 
    
   $text ="你好，仿站请联系客服哦";   
      
  }
  else if(strcasecmp($data, 'seo') == 0){ 
    
    $text = "seo全攻略无非就是内部优化与外部建设同时进行，并且需要用脑子进行。干一件事能否成功，技巧是一方面，更多的是需要坚持，三天打鱼两天晒网只会让自己陷入自我怀疑当中，好好做事，用心做人。seo只要完成这一套完整的优化流程就是最好的技巧，而细致的坚持终有一天一定能够得到回报
    <br/>-------------------<br/>从零基础开始讲解，从概念应用、思维逻辑、基础理论、等多方面着手，教你如何上手利用 SEO 为自己实现副业创收或者转行，提高对seo的背景及逻辑思维的一个全面了解。<br/>
    网站SEO优化步骤基础课程 > <a href='https://www.dpaoz.com/737'>https://www.dpaoz.com/737</a>
    <br/>-------------------<br/>
    【一】常见的域名种类，做网站购买哪些域名<br/>
    【二】购买老域名对网站的利与弊<br/>
    【三】网站结构和链接的优化<br/>
    【四】网站怎么做好外链建设<br/>
    【五】搭建网站后，必须先做的这几件事<br/>
    【六】网站优化编辑文章技巧<br/>
    【七】网站运营的日常工作
    <br/>-------------------<br/>
    上述内容是SEO学习的干货，作为从业多年的SEOer，大家只要按照这个课程学习，那就能把seo系统化的学习到位，透彻的研究！
    ";   
      
  }
  else if(strcasecmp($data, '联系') == 0){ 
    $text ="在浏览设计，运营，优化，建站等资料文章时，感觉到很多新手都碰到各种各样的问题，同时网上真正分享经验比较少。我何不一边学习，一边分享我积累的经验呢。 所以建立了这个网站。 See you in BLOG…<br/>-------------------<br/>
    When browsing design, operation, optimization, website building and other materials and articles, I feel that many novices are confronted with various problems, at the same time, there is less real experience sharing online. Why don't I share my experience while learning. So we set up this website. See you in BLOG…<br/>-------------------<br/>
    联系方式：<a href='https://www.dpaoz.com/about.html'>https://www.dpaoz.com/about.html</a><br/>-------------------<br/>
    QQ：872872015<br/>
    QQ：964240136<br/>
    微信：bylulai<br/>";
    //介绍完主题，然后匹配相关内容推荐
   
  }
  else{
    $text =aiwen_cikuword($data);     
  }
  
  return $text; 
  
}


// 感谢对话
function aiwen__thankwords(){     
      $thankwords = array("别客气，小意思", "能帮上忙实在是我的幸运", "不用谢，这是我活该……啊不，我应该做的", "如果还有其他什么我能帮忙的事情，请随时吩咐。", "你说谢谢我都不好意思让你打赏了（ps：输入[-打赏](゜-゜)","我很强，我知道");
      $rand = rand(0,5);  
      return $thankwords[$rand];  
}
// 怼人对话
function aiwen_fuckwords(){     
      $fuckwords = array("请不要骂人，虽然我不是很懂，但是今后会不断升级完善的", "对不起，没理解您的意思。您可以用一句话描述下您的问题。", "年轻人,你不讲武德啊(゜-゜)つロ", "毁灭吧,我累了", "如果不能说脏话，那我对你也没话可说","如果你觉得我哪里不对，请一定要告诉我，反正我也不会改，你别憋出病来");
      $rand = rand(0,5);  
      return $fuckwords[$rand];  
}
// 全英文全数字对话
function aiwen_ennumwords(){     
      $ennumwords = array("阿鬼!你还是说中文吧!听不懂啊~ -- 《功夫》 ", "对不起，没理解您的意思。您可以用中文描述下您的问题吗", "我没有听懂你在说什么", "啊？你刚刚说什么？", "如果不能说脏话，那我对你也没话可说","如果你说清楚一点我可能会有更好的建议给你");
      $rand = rand(0,5);  
      return $ennumwords[$rand];  
}
// 自我介绍对话
function aiwen_myself(){     
      $myself = array(
      "你好，我是小灯芯AI在线客服，初次见面，请多多指教<br/>-------------------<br/>我的爱好和特长有很多，本人擅长Ai、Fw、Fl、Br、Ae、Pr、Id、Ps等软件的安装与卸载，精通CSS、JavaScript、PHP、ASP、C、C＋＋、C#、Java、Ruby、Perl、Lisp、python、Objective-C、ActionScript、Pascal、spss、sas等单词的拼写，熟悉Windows、Linux、Mac、Android、IOS、WP8等系统的开关机", 
      "最好的工作氛围并不是配有星巴克和健身房的五星级写字楼，也不是带着落地窗的办公室、顶级的办公设备和不限量的零食，而是在你周围有一群优秀和努力的小伙伴，让你的工作和生活变得更加高效和有趣。<br/>-------------------<br/>你好，我是小灯芯AI在线客服，初次见面，请多多指教!"
        );
      $rand = rand(0,1);  
      return $myself[$rand];  
}