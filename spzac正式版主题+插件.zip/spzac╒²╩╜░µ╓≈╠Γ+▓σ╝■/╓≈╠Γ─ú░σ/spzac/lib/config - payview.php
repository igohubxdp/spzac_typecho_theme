<?php

/**
 * config - payview.php
 * Author     : 小灯泡设计
 * Date       : 2020.11.12
 * Version    : 1.0
 * Description: 付费阅读设置
 **/


/** 判断会员是否vip会员 */

function on_userid($userid) {
    
    $db = Typecho_Db::get();
    $userinfo=$db->fetchRow($db->select()->from ('table.users')->where ('table.users.uid=?',$userid));
    $usergroup = $userinfo['group'];
    if ($usergroup=='administrator'||$usergroup=='contributor') {
       return true; //会员返回true
    }
    else{
    return false;//不是会员返回false
    }
}


// 查询是否购买过
function payifok($uid,$cid){
$db = Typecho_Db::get();
$queryUserItem= $db->select()->from('table.teepay_fees')->where('feeuid = ?', $uid)->where('feestatus = ?', 1)->where('feecid = ?', $cid); 
$rowUserItem = $db->fetchRow($queryUserItem);
if(count($rowUserItem)!=null){ 
  return true;//购买过
}
else{
 return false;//没有购买过
    }  
}


function payview($limit,$cid)
{  
  

  
  $settings = $limit;
  $navtops_list = array();
  if (strpos($settings,'|')) {
			//解析关键词数组
			$kwsets = array_filter(preg_split("/(\r|\n|\r\n)/",$settings));
			foreach ($kwsets as $kwset) {
			$navtops_list[] = explode('|',$kwset);
			}
		}
  ksort($navtops_list);  
  if($navtops_list){
  $i = 0;
  $j = 1;	  
  foreach ($navtops_list as $key => $vals) { 
  //内部循环s
    
    $db = Typecho_Db::get();
    $result = $db->fetchAll($db->select()->from('table.contents')->where('cid = ?', $vals[$j]));
    if($result){
       foreach($result as $val){ 
        $val = Typecho_Widget::widget('Widget_Abstract_Contents')->push($val);
        $post_title = htmlspecialchars($val['title']);
        $permalink = $val['permalink'];
        if( $vals[$i]=='0'){ $str='<span class="i_free">[ 阅读 ]</span>'; $url='javascript:;fn_conid('.$vals[$j].')'; }
        else { 
          
          $str='<span class="i_fuei">[ 跳转 ]</span>'; $url=$permalink;
              
        }
               echo '<li><a href="'.$url.'" id="p_'.$vals[$j].'">'.$post_title.'</a><div class="post__views">'.$str.'</div> </li>';
       }
    }       

  //内部循环e
    
    
  }
  }
  
}
  
