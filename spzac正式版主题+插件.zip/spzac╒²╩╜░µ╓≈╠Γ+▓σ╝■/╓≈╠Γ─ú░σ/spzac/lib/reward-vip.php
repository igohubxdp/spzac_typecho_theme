<!-- form -->



<script type="text/javascript">
function show_confirm()
{
var r=confirm("已完成支付，并确认提交？");
if (r==true)
  {
  alert("审核时间预计5分钟左右，请你稍等片刻");
    return true; 
  }
else
  {
  alert("已取消");
    return false;
  }
}
</script>


                        <form action="" method="post" class="input-form form" name=forma onsubmit='return show_confirm();'>
                               
																	
										<div >
											<img class="pay_img" src="<?php $this->options->zfbpay(); ?>">
                                          <img class="pay_img" src="<?php $this->options->wxpay(); ?>">
										</div>
                                   
         
									
										<div class="form__group">
					
                              
                                          
                              <?php if($this->user->hasLogin()): ?>
							  <button class="form__btn" type="submit" name="dosubmit"><span>会员申请</span></button>
                              <?php else: ?>     
                              <button class="form__btn" type="submit" name="dosubmit" disabled="disabled"><span>登录后申请</span></button>            
                              <?php endif; ?>
                                           
										</div>
                            
									
                                    
								
							</form>


<?php
     
    //留言板的思路：1.先创建一个文件名，方便于存放写入的内容
    // 2.将表单中的内容赋值给一个变量
    //3.判断文件是否存在，将用户输入的值写进变量，打开文件的是时候注意选择对文件访问的操作
    //4.读取文件的内容,关闭文件    
    
    $filename = "reward.txt";//创建一个文件的名字     
    //如果用户提交了， 就写入文件， 按一定格式写入
    if(isset($_POST['dosubmit'])) {
    //字段的分隔使用||, 行的分隔使用[n]
      
      
    if($this->user->hasLogin()){
    $username = $this->user->screenName;
    $useruid = $this->user->uid;
    }
    else{
    $username ='游客';
    $userimg ='1234';
    }
  
      
    $dtime = date("Y-m-d H:i",time());  
      
    $mess = "姓名：{$username}，".$dtime."已申请[n]";   
      
    $mess = trim($mess);  //清理空格  

    $mess = strip_tags($mess);   //过滤html标签  

    $mess = htmlspecialchars($mess);   //将字符内容转化为html实体  

    $mess = addslashes($mess);  //防止SQL注入 
  
    $teepay_Server = Helper::options()->plugin('Deng')->iyuukey;       
    file_get_contents('http://iyuu.cn/'. $teepay_Server .'.send?desp='.$mess.'&text='.urlencode('已有人申请会员'));  
     
    writemessage($filename, $mess);//向文件写进内容     
    }     
    if(file_exists($filename)) {//判断文件 是否存在
    readmessage($filename);//读取文件的函数
    }
     
    function writemessage($filename, $mess) {
    $fp = fopen($filename, "a");//在尾部执行写的操作，且不删除原来的文件内容
    fwrite($fp, $mess);//写入文件     
    fclose($fp);//关闭文件     
    header('location:/');     
    }     
    function readmessage($filename) {
    $mess = file_get_contents($filename);
    $mess = rtrim($mess, "[n]");     
    $arrmess = explode("[n]", $mess);
     
   // foreach($arrmess as $m) {
   // list($username, $dt ,$title, $content) = explode("，", $m);
   // $time = date("Y-m-d H:i",$dt);
   // echo "<li>".$time."<br/> {$username} {$title} {$content}</li>";
   // }     
    }
     
    ?>