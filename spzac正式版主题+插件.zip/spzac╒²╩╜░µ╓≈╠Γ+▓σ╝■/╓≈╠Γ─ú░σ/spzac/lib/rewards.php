<!-- form -->




                        <form action="" method="post" class="input-form form" name=forma onsubmit='return show_confirm();'>
                                <?php if(!$this->user->hasLogin()): ?>
							    <div class="comment-overlay">                           
                                  <div class="comment-overlay-login"><p>您必须<a href="<?php $this->options->signin(); ?>">登录</a>或<a href="<?php $this->options->signup(); ?>">注册</a>以后提交工单哦~</p></div>                                  
                                </div>
                                <?php endif; ?>
								<div class="row">
									<div class="col-12">
										<h2 class="form__title">打赏支持</h2>
									</div>
								
                                  <style>
                                    .ds-money {  display: flex;  flex-flow: wrap;margin-bottom: 10px;}
                                    .ds-money li {   width: 16.6666%;}
                                    .ds-item {  cursor: pointer;    height: 50px;}
                                    .ds-item i { font-size: 18px;}
                                    .ds-item span{ margin:0 2px}
                                    .picked .ds-item {   border-color: #f16b6f;  color: #f16b6f;}
                                    .picked  i{ color: #f16b6f; }
                                    .ds-item:hover{  border-color: #f16b6f;  color: #f16b6f; }
                                    .ds-item:hover i{  color: #f16b6f; }
                                    .ds-item {
    padding: 10px;
   
    margin: 5px;
    border: 1px solid #ddd;
    text-align: center;
  
    display: flex;
    justify-content: center;
    align-items: flex-end;
    border-radius: 3px;
}
                                  </style>
                                  
                                  <div class="col-12 col-lg-12">
                                    
                                     <label class="form__label">打赏:</label>
                                    <ul class="ds-money">
                                    <li><div class="ds-item" id="re_2"><i class="icon iconfont icon-ic_support_line"></i> <span>2</span><b>￥</b></div></li>
                                    <li><div class="ds-item" id="re_5"><i class="icon iconfont icon-ic_support_line"></i> <span>5</span><b>￥</b></div></li>
                                    <li><div class="ds-item" id="re_10"><i class="icon iconfont icon-ic_support_line"></i> <span>10</span><b>￥</b></div></li>
                                    <li><div class="ds-item" id="re_20"><i class="icon iconfont icon-ic_support_line"></i> <span>20</span><b>￥</b></div></li>
                                    <li><div class="ds-item" id="re_50"><i class="icon iconfont icon-ic_support_line"></i> <span>50</span><b>￥</b></div></li>
                                    <li class="picked"><div class="ds-item" id="re_0"><i class="icon iconfont icon-ic_support_line"></i> <span>自定义</span></div></li>
                                    </ul>
                                   
                                  </div>
                                
                                  <div class="col-12 col-lg-6">
										<div class="form__group ">
											<label class="form__label">打赏:</label>
                                            <input id="reward" type="text" class="form__input" value="">
										</div>
									</div>
                                  
                                  <div class="col-12 col-lg-6">
										<div class="form__group">
											<label class="form__label">留言:</label>
											<input  type="text" class="form__input" value="">
										</div>
									</div>
                                  
                                  <div class="col-12">
                                        <input name="do" type="hidden" value="profile">
										<button class="form__btn" type="submit" name="dosubmit"><span>打赏</span></button>
									</div>
                                    
								</div>
							</form>

