<?php

/**
 * config - menber.php
 * Author     : 小灯泡设计
 * Date       : 2020/4/3
 * Version    : 1.0
 * Description: 会员-积分配置
 **/
 

// 判断文章是否存在付费订单 
function on_paypost($id){
	//https://www.dpaoz.com/idown.html?id=
    $idown = Helper::options()->idown;	
    $db=Typecho_Db::get();
    $payost = $db->fetchRow($db->select()->from('table.contents')->where('cid = ?',$id));  
    $price = $payost['teepay_price'];
    $content = $payost['teepay_content'];  
    if($content!=null){
    echo '<div style="border-top: 1px solid rgba(0, 0, 0, .05); padding:35px 15px 10px;position: relative;z-index:999;margin: 15px 0 0;">
				       <div style="padding: 10px; background: #f0f4f5; font-size: 12px;font-weight: 400; border-radius: 6px; margin: 10px 5px 0;">
						    <div style="border:none;-moz-border-radius: 0px;-webkit-border-radius: 0px;border-radius:0px; float:left;">
							￥ '.$price.'元
							</div>
							<span class="d_plei">可下载</span>
							<div style="clear:left;"></div>
				       </div>
				       <div style="clear:left;"></div>
				       <div class="user__btns" style="padding: 10px 5px;">
				       <a href="'. $idown.'?id='.$id.'" class="user__btn user__btn--orange user__down" ><span>资源下载</span></a>						
				       </div>
				       <span style="position: absolute;top:10px;left:15px;font-size:90%;color:#90949c;">vip下载地址</span>
				       <span style="position: absolute;top:10px;right:15px;"><img style="width:22px;" src="/usr/plugins/TeePay/pay.png" alt=""></span>
			           </div>';	
    }
	
}

// 判断用户收益 get_income($myuid);
function get_income($id){  

    $db=Typecho_Db::get();
    $userinfo=$db->fetchRow($db->select()->from ('table.users')->where ('table.users.uid=?',$id));
    $created = date('Y-m-d', $userinfo['created']);  
    $inrow = $db->fetchRow($db->select(array('Sum(feeprice)'=>'allincome'))->from('typecho_teepay_fees')->where('feestatus=?', '1')->where ('feeinstime>?',$created));
	$income = $inrow['allincome'];     
    $income = $income*0.01;
	return $income;
  
}  
  
// 合伙人收益分成
function get_inshare($id){ 
    $p=0;
    $db=Typecho_Db::get();
    $userinfo=$db->fetchAll($db->select('cid')->from('typecho_fields')->where('name=?', 'inshare')->where ('str_value=?',$id));    
    if($userinfo){
      foreach($userinfo as $val){
        $cid = $val['cid'];
        
        $info = $db->fetchAll($db->select(array('SUM(feeprice)'=>'price'))->from('typecho_teepay_fees')->where('feecid = ?',$cid)->where('feestatus=?', '1'));
        foreach ($info as $sl){
          $price=$sl['price'];
        }
        $p = $p+$price; 
      }
       $p = $p*0.3;
       echo $p;
    }
    else{
    echo 0;
    }
} 
  
  

/**
* 积分生成 暂时无用
* 调用<?php get_points($uid,数值积分); ?>
*/
function get_points($uid,$upsum) {
    $db = Typecho_Db::get();
    $cid = $uid;
    if (!array_key_exists('points', $db->fetchRow($db->select()->from('table.users')))) {
        $db->query('ALTER TABLE `'.$db->getPrefix().'users` ADD `points` INT(10) DEFAULT NULL;');         
        }
    
    $exist = $db->fetchRow($db->select('points')->from('table.users')->where('uid = ?', $cid))['points']; 
   // $vid = 'DP'.$cid;
    if($exist == null){       
       $secy = 0;          
            $db->query($db->update('table.users')
                ->rows(array('points' =>$secy))
                ->where('uid = ?',$cid));
       $exist = $db->fetchRow($db->select('points')->from('table.users')->where('uid = ?', $cid))['points'];        
    }
    else{
         if($upsum!=null){
         $db->query($db->update('table.users')
                ->rows(array('points' =>(int)$exist+$upsum))
                ->where('uid = ?',$cid));
         }  
         $exist = $db->fetchRow($db->select('points')->from('table.users')->where('uid = ?', $cid))['points'];   
    }
  
    echo $exist;
}
  

function get_logins($sum) {
 $db = Typecho_Db::get();
  $current = $db->fetchAll($db->select()->from('table.users')
   // ->page($currentPage, $pageSize)
   // ->where('group = ?', 'contributor') 
    ->where('uid <> ?', '1') //排除站长             
    ->limit($sum)                       
    ->order('activated', Typecho_Db::SORT_DESC));
    foreach($current as $line){   
    $gethml =  $gethml.'<li class="inline-items js-chat-open"><div class="author-thumb"><a href="'.Helper::options()->siteUrl.'author/'.$line['uid'].'"><img title="'.$line['name'].'-'.get_last_login($line['uid']).'" src="'.getGravatar($line['mail']).'" class="avatar"></a><span class="icon-status online"></span></div></li>';
   }
   return $gethml;
  
}

