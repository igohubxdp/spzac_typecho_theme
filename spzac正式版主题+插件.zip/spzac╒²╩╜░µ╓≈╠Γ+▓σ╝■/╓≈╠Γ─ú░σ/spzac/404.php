<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;
 $this->need('header.php');
 ?>
<!-- main content -->
<main class="main main--breadcrumb">
		<div class="col-md-12" id="content">
			<div class="error-page">
				<h1 class="not-found-title">404</h1>
				<a class="not-found-back" href="<?php $this->options->siteUrl(); ?>">返回主页</a>
			    <p>你想查看的页面已被转移或删除了, 要不搜索看看: </p>	       
			</div>
		</div>
</main>
<!-- end main content -->
<!-- footer -->
<?php $this->need('footer.php'); ?>
<!-- end footer -->

