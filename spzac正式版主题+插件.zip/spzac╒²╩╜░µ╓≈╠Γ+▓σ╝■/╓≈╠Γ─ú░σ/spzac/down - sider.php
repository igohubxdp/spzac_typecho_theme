<div class="col-12 col-md-5 col-lg-4 col-xl-3 fixsidenav">

                    <?php if ($this->is('post')): ?>
                    <!-- user -->
					<div class="user fixside downon">
						<div class="user__head  bg_color">
							<div class="user__img">
								<img src="<?php $this->options->blogme(); ?>" alt="<?php $this->options->title() ?>">
							</div>
						</div>
						
						<div class="user__title">							
							<p>版权申明：本素材由本站发布，用户购买后只有终端使用权，禁止转售和转载</p>
						</div>

						<!--免费下载-->
                        <?php if ($this->fields->down): ?>
						<div class="user__btns">
						<a href="<?php $this->fields->down(); ?>" class="user__btn user__btn--blue user__down"><span>免费下载</span></a>
						</div>
                        <?php endif;?>
                        <!--免费下载-->

                        <!--注册下载-->
                        <?php if($this->fields->downb): ?><?php if($this->user->hasLogin()): ?>						
                        <div class="user__btns">
						<a href="<?php $this->fields->downb(); ?>" class="user__btn user__btn--orange user__down" ><span>会员下载</span></a>
						</div>
                        <?php else: ?>
                        <div class="user__btns" id="autip">
						<a href="javascript:void(0);" class="user__btn user__btn--orange user__down" ><span>会员下载</span></a>						
						</div>
                        <?php endif;?><?php endif;?>
						<!--注册下载e-->
                                          					
                        <nocompress>
                        <?php echo TeePay_Plugin::getTeePay(); ?>
                        </nocompress>	
                      
                        <!--vip用户-->
                       <?php if($this->user->hasLogin()): ?>
                       <?php if($this->user->group == 'administrator'||$this->user->group == 'contributor'): ?>
                       <?php on_paypost($this->cid); ?>
                       <?php endif;?>
                       <?php endif;?>
                        <!--vip用户s-->
                        
                       
                      
					</div>
					<!-- end user -->
					<?php endif; ?> 
  
                   
  
</div>

