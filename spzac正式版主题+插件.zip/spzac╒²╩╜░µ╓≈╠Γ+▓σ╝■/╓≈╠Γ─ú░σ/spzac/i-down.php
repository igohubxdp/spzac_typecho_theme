<?php
/**
* 下载页面
*
* @package custom
*/

if (!defined('__TYPECHO_ROOT_DIR__')) exit;
 $this->need('header.php');
 ?>



<!--登录，判断是否会员s-->
<?php 

function writemessage($filename, $mess) {
    $fp = fopen($filename, "a");//在尾部执行写的操作，且不删除原来的文件内容
    fwrite($fp, $mess);//写入文件     
    fclose($fp);//关闭文件   
    }    

$tid=$_GET['id']; 

if ($this->user->hasLogin()){  
  
  $info=userok($this->user->uid);
  $mygroup=$info['group'];
  if($mygroup == 'administrator'||$mygroup == 'contributor')
   {
    
    $db = Typecho_Db::get();
    $userow = $db->fetchRow($db->select()->from('table.contents')->where('cid = ?',$tid));
    
    $mycontent=$userow['teepay_content']; 
    $stitle=$userow['title'];    
    $suerid=$this->user->uid;
    
    $this->widget('Widget_Archive@indexxiu', 'pageSize=1&type=post', 'cid='.$tid)->to($palyji);
    
     //写入记事本
     $filename = "idown.txt";//创建一个文件的名字 
     if(file_exists($filename)) {//判断文件 是否存在 
     $mess = "{$suerid}|".time()."|{$stitle}[n]";  
     writemessage($filename, $mess);//向文件写进内容
     }
       
   
    
  }
   else{ header("Location: /");}
    
}
else{
  header("Location: /");
}


   

?>

<div class="sign">
<div class="container">
<div class="row">
<div class="col-12">
<div class="sign__content">
<div class="typecho-login" style="display: none;"></div>
<div  class="sign__form">
<a href="<?php $this->options->siteUrl(); ?>" class="sign__logo">
<img src="<?php $this->options->logoUrl();?>" alt="">
</a>


							<a href="<?php echo $mycontent; ?> " class="user__btn user__btn--blue user__down" ><span> 点击下载</span></a>	                           
						
<span class="sign__text"><?php echo $stitle; ?>  <a href="<?php $palyji->permalink() ?>"> > 返回</a></span> 
</div >                        
</div>
</div>
</div>
</div>
</div>

	<!-- footer -->
	<?php $this->need('footer.php'); ?>
	<!-- end footer -->
