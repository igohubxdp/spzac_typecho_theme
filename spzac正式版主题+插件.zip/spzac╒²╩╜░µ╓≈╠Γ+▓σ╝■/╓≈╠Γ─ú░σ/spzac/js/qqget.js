function fn_qqinfo() {
	var qq_num = $('#qqinfo').val();
   
	if (qq_num) {
		if (!isNaN(qq_num)) {
			$.ajax({
				url: "/usr/themes/spzac/lib/get_qq_info.php",
				type: "POST",  
				data: {
					qq: qq_num,                    
				},
                async: true,                          
				dataType: "json",
				success: function(data) {
					$("#mail").val(qq_num + '@qq.com');
					$('#comment').focus();
					if (data == null) {
						$("#author").val('QQ游客');
					} else {
						$("#author").val(data.name == "" ? 'QQ游客' : data.name);
                      $('div.ajax-user-avatar img').attr('src',data.qqtx);                      	
					}
				},
				error: function(err) {
					$("#author").val('QQ游客');
					$("#mail").val(qq_num + '@qq.com');
					$('#comment').focus();
				}
			});         

                     
          
		} else {
			
			$("#mail").val('你输入的好像不是QQ号码');
		}
	} else {
		$("#mail").val('请输入QQ号来获取');
		
	}
}
