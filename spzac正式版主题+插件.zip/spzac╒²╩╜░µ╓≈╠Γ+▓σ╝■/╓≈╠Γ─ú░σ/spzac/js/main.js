
// 插入下载

jQuery(document).ready(function(a) {
      if (/(iPhone|iPad|iPod|iOS)/i.test(navigator.userAgent)) {
   a(".downon").appendTo(".downmoi") ;
      
} else if (/(Android)/i.test(navigator.userAgent)) {
  a(".downon").appendTo(".downmoi") ;
} else { 
};  
});


$(document).ready(function () {
	"use strict"; // start of use strict

	/*==============================
	Menu
	==============================*/
	$('.header__btn').on('click', function() {
		$(this).toggleClass('header__btn--active');
		$('.header__nav').toggleClass('header__nav--active');
	});

	/*==============================
	Back
	==============================*/
	$('.footer__back').on('click', function() {
		$('body,html').animate({
			scrollTop: 0,
			}, 700
		);
	});
  
    
    /*==============================
	侧边栏固定
	==============================*/
     $(window).scroll(function() {
     var t = $(document).scrollTop();
     var r = $(".fixside").height()
     var s = $(".fixsidenav").height();
     s = s - r;
     if (t < 100) {
         $(".fixside").removeClass('fiesd-top');
     } else {
         $(".fixside").addClass('fiesd-top');
     }
     if (t > s) {
        /* $(".fixside").removeClass('fiesd-top');
         $(".fixside").addClass('fiesd-bottom');*/
     } else {
         $(".fixside").removeClass('fiesd-bottom');
     }
 });

	/*==============================
	Range sliders
	==============================*/
	function initializeSlider() {
		if ($('#filter__range').length) {
			var firstSlider = document.getElementById('filter__range');
			noUiSlider.create(firstSlider, {
				range: {
					'min': 0,
					'max': 100
				},
				step: 1,
				connect: true,
				start: [18, 34],
				format: wNumb({
					decimals: 0,
					prefix: '$'
				})
			});
			var firstValues = [
				document.getElementById('filter__range-start'),
				document.getElementById('filter__range-end')
			];
			firstSlider.noUiSlider.on('update', function( values, handle ) {
				firstValues[handle].innerHTML = values[handle];
			});
		} else {
			return false;
		}
		return false;
	}
	$(window).on('load', initializeSlider());

});



// hljs行号
$("pre code").each(function(){
  $(this).html("<ol><li>" + $(this).html().replace(/\n/g,"\n</li><li>") +"\n</li></ol>");
});

// 插入移动端边栏

jQuery(document).ready(function(a) {
      if (/(iPhone|iPad|iPod|iOS)/i.test(navigator.userAgent)) {
   a(".s_ping").appendTo(".header__nav") ;
        a(".header__nav").toggleClass("sxx");
} else if (/(Android)/i.test(navigator.userAgent)) {
   a(".s_ping").appendTo(".header__nav") ;
   a(".header__nav").toggleClass("sxx");
} else { 
};  
});


// 下载提示
$(function(){
  $("#autip").click(function(){
  alert('请先注册会员哦~');
 }); 
});

function u_alert()
  {
  alert("该课程需要购买后阅读哦")
  } 


$(function() {
        //scroll 事件适用于所有可滚动的元素和 window 对象（浏览器窗口）。
        $(window).scroll(function() {
                var scroHei = $(window).scrollTop();//滚动的高度
                if (scroHei > 500) {
                   $('.back-to-top').css('top','-200px');
                   // $('.back-to-top').fadeIn();
                } else {                                                
                    $('.back-to-top').css('top','-999px');
                    // $('.back-to-top').fadeOut();
                }
            })
            /*点击返回顶部*/
        $('.back-to-top').click(function() {
            $('body,html').animate({
                scrollTop: 0
            }, 600);
        })
    })

$(function() {
 if ($("#reward").length > 0) {                                                                   
    $('#re_2').click(function(){ $('#reward').val($('#re_2 span').text()); $('#reward').attr("disabled","disabled"); })
    $('#re_5').click(function(){ $('#reward').val($('#re_5 span').text()); $('#reward').attr("disabled","disabled");  })
    $('#re_10').click(function(){ $('#reward').val($('#re_10 span').text()); $('#reward').attr("disabled","disabled");  })
    $('#re_20').click(function(){ $('#reward').val($('#re_20 span').text()); $('#reward').attr("disabled","disabled");  })
    $('#re_50').click(function(){ $('#reward').val($('#re_50 span').text()); $('#reward').attr("disabled","disabled"); })
    $('#re_0').click(function(){   $("#reward").val("");  $('#reward').removeAttr("disabled"); $('#reward').focus();  })    
   	}  
  })


// -----------------------------------最近访客--------------------------------
  $(document).ready(function(){
    var num =parseInt($(window).height()/50-1);
    console.log(num);
    fn_geuser(num);
  })
    
function fn_geuser(a) { //最近访客*数量
	var genum = a;
	if (genum) {
		if (!isNaN(genum)) {
			$.ajax({				
                url: globals.ajax_url,
				type: "POST",  
				data: {
					genum: genum,                    
				},
                async: true,                          
				dataType: "json",
				success: function(data) {	
					if (data == null) {						
					} else {                    
                     $(".chat-users").html(data.vuser); 
					}	
				},
				error: function(err) {
					alert('加载失败');
				}
			});   
		} else {
		alert('加载失败');
		}
	} else {
	alert('加载失败');
	}
}
//