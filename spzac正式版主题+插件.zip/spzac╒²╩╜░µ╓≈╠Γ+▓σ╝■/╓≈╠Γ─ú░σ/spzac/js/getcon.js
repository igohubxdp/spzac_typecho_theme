function fn_conid(a) {
	var conid = a;
	
	$("#fu_con").before("<div class='postpj'><div class='loading-5'><i></i><i></i></div></div>");
   
	if (conid) {
		if (!isNaN(conid)) {
			$.ajax({				
                url: globals.ajax_url,
				type: "POST",  
				data: {
					id: conid,                    
				},
                async: true,                          
				dataType: "json",
				success: function(data) {					
					
					if (data == null) {						
					} else {
                     $("#pview").remove(); 
                     $("#post_tit").html(data.vtit); 		
			         $("#post_ttx").html(data.vcon); 
                     $("#p_"+conid+"").after("<span id='pview' ><i class='icon-living'></i> 正在阅读.....</span>"); 
			         $(".postpj").remove();      	
					}				
					
				},
				error: function(err) {
					alert('加载失败');
				}
			});    
          
		} else {
		alert('加载失败');
		}
	} else {
	alert('加载失败');
		
	}
}
