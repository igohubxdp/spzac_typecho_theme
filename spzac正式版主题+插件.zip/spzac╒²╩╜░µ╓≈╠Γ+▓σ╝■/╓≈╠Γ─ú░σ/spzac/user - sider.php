<div class="col-12 col-md-5 col-lg-4 col-xl-3 <?php if ($this->is('page', $this->options->vipbuys)): ?>sider_none<?php endif; ?>">
					<!-- user -->
					<div class="user sidebox">
						<div class="user__head bg_color">
							<div class="user__img">
                                
								<img src="<?php $this->options->blogme(); ?>" alt="<?php $this->options->title() ?>">
							</div>
						</div>
                     
						<div class="user__title">
							<h2><?php $this->options->title() ?></h2>
							<p><?php $this->options->description() ?></p>
						</div>
						<?php $this->need('assets/side - nav.php'); ?>
					<div class="sidebox__content">
                      
<?php 
$slidenum = $this->options->tipid;
$hang = explode(",", $slidenum);
$n=count($hang);
$html="";
for($i=0;$i<$n;$i++){
$this->widget('Widget_Archive@kans'.$i, 'pageSize=1&type=post', 'cid='.$hang[$i])->to($ji);
if($i==0){$no=" sx_no";}else{$no="";}
$created = date('m-d', $ji->created);
$html=$html.' <div class="sidebox__job"><div class="sidebox__job-title"><a href="'.$ji->permalink.'">'.$ji->title.'</a><span><i class="icon iconfont icon-ic_message_line"></i></span></div></div>';
}
echo $html;
?>               
                      
</div>
<div class="sidebox__more">网站简介</div>
</div>
<!-- end user -->
  

<div class="sidebox"> <h4 class="sidebox__title">最新消费</h4> <i class="bg-primary"></i> 

<?php pay_list(); ?>

</div>                
					                   


</div>