<?php

/**
* 付费功能表单
*
* @package custom
*/

if (!defined('__TYPECHO_ROOT_DIR__')) exit;
$this->need('header.php');
?>

	<!-- main content -->
	<main class="main main--breadcrumb">
		<!-- breadcrumb -->
		<?php $this->need('assets/post - link.php'); ?>
		<!-- end breadcrumb -->

		<div class="container">
			<div class="row neipage">
				<!-- header -->
	            <?php $this->need('user - sider.php'); ?>
	            <!-- end header -->

				<div class="col-12 col-md-7 col-lg-8 col-xl-9">
                  
<!--幻灯片-->
<div class="post post-ad"><img src="https://xiao.dpaoz.com/webcad.png"></div>
<!--幻灯片-->
 

               
<!--打赏支付-->
<?php $this->need('assets/get-vip.php'); ?>
<!--打赏支付-->      

                  
                 
                  
					<!-- faq -->
					<div class="faq seoxue">
						<div class="row">                         

                            <div class="col-12">
								<div class="faq__box">
									<h3>服务器环境安装</h3>
									<ul class="web_lis">                             
                                    <li><i class="icon iconfont icon-ic_right_line1"></i>网站搭建，服务器环境搭建 <div class="post__views"><span class="i_fuei">[ 付费 ￥30.00 ]</span></div> </li>  
                                    <li><i class="icon iconfont icon-ic_right_line1"></i>网站搬家服务 <span>( 主流程序搬家迁移 )</span><div class="post__views"><span class="i_fuei">[ 付费 ￥50.00 ]</span></div> </li>   
                                    <li><i class="icon iconfont icon-ic_right_line1"></i>网站内容搭建，布局运营，图片美化，前端优化<span>( 试运营30天 )</span><div class="post__views"><span class="i_fuei">[ 付费 ￥200.00 ]</span></div> </li> 
                                    <li><i class="icon iconfont icon-ic_right_line1"></i>网站搭建，修改，调整 <span>( 简单的网站小问题 )</span><div class="post__views"><span class="i_fuei">[  ￥随意小打赏 ]</span></div> </li>      
									</ul>
								</div>
							</div>                     
						

						
                           <div class="col-12">
								<div class="faq__box">
									<h3>主题定制开发</h3>
                                    <p class="main__box-text">仿站不一定100%,仿站需注意下面的报价费用和范围</p>
									<ul class="web_lis">
                                    <li><i class="icon iconfont icon-ic_right_line1"></i>Typecho主题仿制定制 <span>( 响应式布局，优化PC、iPad和各种手机端用户体验 )</span><div class="post__views"><span class="i_fuei">[ 付费 ￥200起 ]</span></div> </li>
                                    <li><i class="icon iconfont icon-ic_right_line1"></i>Wordpress主题仿制定制 <span>( 响应式布局，优化PC、iPad和各种手机端用户体验 )</span><div class="post__views"><span class="i_fuei">[ 付费 ￥300起 ]</span></div> </li>  
                                    <li><i class="icon iconfont icon-ic_right_line1"></i>Zblog主题仿制定制 <span>( 响应式布局，优化PC、iPad和各种手机端用户体验 )</span><div class="post__views"><span class="i_fuei">[ 付费 ￥300起 ]</span></div> </li>
                                    <li><i class="icon iconfont icon-ic_right_line1"></i>Maccms主题仿制定制 <span>( 响应式布局，优化PC、iPad和各种手机端用户体验 )</span><div class="post__views"><span class="i_fuei">[ 付费 ￥300起 ]</span></div> </li>
                                    <li><i class="icon iconfont icon-ic_right_line1"></i>Dedecms主题仿制定制 <span>( 响应式布局，优化PC、iPad和各种手机端用户体验 )</span><div class="post__views"><span class="i_fuei">[ 付费 ￥200起 ]</span></div> </li>  
									</ul>
								</div>
							</div>
							

			
						</div>
					</div>
					<!-- end faq -->
				</div>
			</div>
		</div>
	</main>
	<!-- end main content -->

	<!-- footer -->
	<?php $this->need('footer.php'); ?>
	<!-- end footer -->
