<?php
/**
* 注册页面
*
* @package custom
*/
include 'lib/common.php';
if (!defined('__TYPECHO_ROOT_DIR__')) exit;
 $this->need('header.php');
 ?>

<div class="sign">
<div class="container">
<div class="row">
<div class="col-12">
<div class="sign__content">

<?php if($this->user->hasLogin()): ?>
<script language="javascript" type="text/javascript">
window.location.href='<?php $this->options->siteUrl(); ?>';
</script>  
<?php endif; ?>

<div class="typecho-login" style="display: none;"></div>
<form action="<?php $this->options->registerAction();?>" method="post" name="register" role="form" class="sign__form">
<input type="hidden" name="_" value="<?php echo $this->security->getToken($this->request->getRequestUrl());?>">
<input type="hidden" name="referer" value="<?php $this->options->siteUrl(); ?>" />
<a href="<?php $this->options->siteUrl(); ?>" class="sign__logo">
<img src="<?php $this->options->logoUrl();?>">
</a>  
<?php if($this->options->allowRegister): ?>
<?php if($this->options->qqget == '1'): ?>
<div class="sign__group"> 
<input type="text" class="form-control sign__input bot_sign" name="qqinfo" id="qqinfo" placeholder="QQ号可获取头像和昵称" onblur="fn_qqinfo()" required="required">  
<script src="<?php $this->options->themeUrl('js/qqget.js'); ?>"></script>    
</div>
<?php endif; ?> 
<div class="sign__group"> 
<input type="text" id="author" name="name" class="sign__input" placeholder="用户名">
</div>
<div class="sign__group">
<input type="email" id="mail" name="mail"  class="sign__input" placeholder="邮箱地址">
</div>
<div class="sign__group">
<input type="password" id="password" name="password" autocomplete="current-password" placeholder="输入密码" required  class="sign__input">
</div>    
<div class="sign__group">
<input type="password" id="confirm" name="confirm" autocomplete="current-password" placeholder="再次输入密码" required  class="sign__input">
</div>
<button class="sign__btn" type="submit" name="loginsubmit" value="true"><span>注 册</span></button>
<span class="sign__text">请妥善保管好密码~ <a href="<?php $this->options->signin(); ?>">返回登录!</a></span>  
<?php else: ?>
<span class="sign__text">注册功能已关闭</span>
<?php endif; ?>    
</form>  
</div>
</div>
</div>
</div>
</div>

<!-- footer -->
<?php $this->need('footer.php'); ?>
<!-- end footer -->
<?php
echo '<link rel="stylesheet" href="' . Typecho_Common::url('style.css?v=' . $suffixVersion, $options->adminStaticUrl('css')) . '">';
include __ADMIN_DIR__ . '/common-js.php';
?>
