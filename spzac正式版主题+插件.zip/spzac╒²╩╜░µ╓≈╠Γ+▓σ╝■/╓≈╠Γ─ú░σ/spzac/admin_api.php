<?php 


$period = time() - 86400;
$stime = date("Y-m-d H:i",$period);

$db = Typecho_Db::get();
// 查询是否有会员准备到期
$userinfo= $db->select()->from('table.users')->where('group = ?', "contributor")->order('uid',Typecho_Db::SORT_DESC)->limit(20); 
$row = $db->fetchAll($userinfo);
if($row){ 
  foreach($row as $val){ 
    $endtime = $val['endtime'];
    if($endtime!=null){
     
    $now = time();
    $d2 = ceil(($endtime-$now)/60/60/24);
      if($d2<10){
        $timemess= $timemess.$val['screenName'].'会员期限准备过期，还差'.$d2.'天\n\n';
      } 
      else{  $timemess= '近10天暂时无会员过期哦'; }
    }    
  }
}

// 查询昨天有多少个订单

$payinfo= $db->select()->from('typecho_teepay_fees')->order('table.teepay_fees.feeid',Typecho_Db::SORT_DESC)->limit(30); 
$pow = $db->fetchAll($payinfo);
if($pow){
    $i=0;
    $j=0;
    $nows = time();  
   foreach($pow as $pal){       
   $ptime= strtotime($pal['feeinstime']);  
   $d2 = ceil(($nows-$ptime)/60/60/24);     
   if($d2<=1){ 

    if($pal['feestatus']==1){ $j=$j+1;}
    $i=$i+1;
   }   
  }
   $paymess = '昨天一共有'.$i.'个订单,其中'.$j.'个支付成功';  
}


// 查询昨天有多少人注册
$zcinfo=$db->fetchAll($db->select()->from ('table.users')->limit(20)->order('created',Typecho_Db::SORT_DESC));
if($zcinfo){
  $zc=0;
  $now = time();  
  foreach($zcinfo as $vual){ 
    $ztime= $vual['created']; 
    $d3 = ceil(($now-$ztime)/60/60/24);
    if($d3<=1){ 
    $zc=$zc+1;
    }
  }
  $zcmess = '昨天注册了'.$zc.'个会员';
}


// 查询数据流量蜘蛛统计
$all = Typecho_Plugin::export();
if (array_key_exists('Access', $all['activated'])){

$tjinfoa=$db->fetchAll($db->select(array('COUNT(robot)'=>'robota'))->from ('typecho_access_log')->where('time > ?', $period)->where('robot = ?', '0'));//用户
if($tjinfoa){
  foreach($tjinfoa as $tala){ 
    $robota=$tala['robota'];   
  }
  
}

$tjinfob=$db->fetchAll($db->select(array('COUNT(robot)'=>'robotb'))->from ('typecho_access_log')->where('time > ?', $period)->where('robot = ?', '1'));//蜘蛛
if($tjinfob){
  foreach($tjinfob as $talb){ 
    $robotb=$talb['robotb'];   
  } 
}
  
$tjip=$db->fetchAll($db->select('COUNT(distinct ip) AS ipnum')->from ('typecho_access_log')->where('time > ?', $period));//ip统计
if($tjip){
   foreach($tjip as $ipval){ 
  $ipnum=$ipval['ipnum'];
  }
}
  
 $tjmess = '访问用户：'.$robota.'PV，'.$ipnum.'IP，蜘蛛爬行：'.$robotb.'次';
  
}
else{
 $tjmess ='暂无统计信息'; 
}


$aid=$_GET["aid"];

$apikey = $this->options->apikey;

if($aid==$apikey){  

$sckey = Helper::options()->plugin('Deng')->iyuukey;

$text = "早报：昨日数据统计";
$desp = "**".$stime."**\n\n注册统计：".$zcmess."\n\n订单统计：".$paymess."\n\n会员统计：".$timemess."\n\n流量统计：".$tjmess;      
      
        $postdata = http_build_query(
    array(
        'text' => $text,
        'desp' => $desp
        )
    );
$opts = array('http' =>array(
        'method'  => 'POST',
        'header'  => 'Content-type: application/x-www-form-urlencoded',
        'content' => $postdata
        ),
        // 解决SSL证书验证失败的问题
        "ssl"=>array(
            "verify_peer"=>false,
            "verify_peer_name"=>false,
        )
    );
$context  = stream_context_create($opts);
$result = file_get_contents('https://iyuu.cn/'. $sckey .'.send', false, $context);
}

?>


<?php

/**
* BT任务发送
*
* @package custom
*/

if (!defined('__TYPECHO_ROOT_DIR__')) exit;
$this->need('header.php');
?>

	<!-- main content -->
	<main class="main main--breadcrumb">
		<!-- breadcrumb -->
		<?php $this->need('assets/post - link.php'); ?>
		<!-- end breadcrumb -->

		<div class="container">
			<div class="row neipage">
				<!-- header -->
	            <?php $this->need('user - sider.php'); ?>
	            <!-- end header -->

				<div class="col-12 col-md-7 col-lg-8 col-xl-9">
                  
<!--幻灯片-->
<div class="post post-ad"><img src="https://xiao.dpaoz.com/webcad.png"></div>
<!--幻灯片-->
 
<!--栏目描述-->
<div class="main__box"> <h3 class="main__box-title">站点信息</h3> <div class="bg_cl">  
<p class="main__box-text"><?php echo $timemess; ?></p>
<p class="main__box-text"><?php echo $paymess; ?></p>
<p class="main__box-text"><?php echo $zcmess; ?></p> 
<p class="main__box-text"><?php echo $tjmess; ?></p>
<p class="main__box-text" style="color: #f60;">开通请联系客服！！</p>
</div> </div> 
<!--栏目描述-->
                  

				</div>
			</div>
		</div>
	</main>
	<!-- end main content -->

	<!-- footer -->
	<?php $this->need('footer.php'); ?>
	<!-- end footer -->
