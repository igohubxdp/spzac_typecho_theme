<?php
class Deng_Action extends Typecho_Widget implements Widget_Interface_Do
{
	private $db;
	private $options;
	private $prefix;
			

	public function updateDeng()
	{
		if (Deng_Plugin::form('update')->validate()) {
			$this->response->goBack();
		}

		/** 取出数据 */
		$post = $this->request->from('uid', 'screenName', 'endtime');
      
        
        $post['endtime'] = strtotime(date($post['endtime']));

		/** 更新数据 */
		$this->db->query($this->db->update($this->prefix.'users')->rows($post)->where('uid = ?', $post['uid']));

		/** 设置高亮 */
		$this->widget('Widget_Notice')->highlight('post-'.$post['cid']);

		/** 提示信息 */
		$this->widget('Widget_Notice')->set(_t('用户信息已经被更新',
		$post['screenName'], $post['endtime']), NULL, 'success');

		/** 转向原页 */
		$this->response->redirect(Typecho_Common::url('extending.php?panel=Deng%2Fhtml/posts.php', $this->options->adminUrl));
	}


	public function action()
	{
		$user = Typecho_Widget::widget('Widget_User');
        $user->pass('administrator');
		$this->db = Typecho_Db::get();
		$this->prefix = $this->db->getPrefix();
		$this->options = Typecho_Widget::widget('Widget_Options');
		$this->on($this->request->is('do=update'))->updateDeng();
		$this->response->redirect($this->options->adminUrl);
	}
}
