<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;
/**
 * 针对spzac主题的用户会员登录注册，找回密码等相关用户社区开发插件
* <div class="FansSet"><a href="https://www.dpaoz.com/" target="_blank">官网问题反馈</a>&nbsp;</div><style>.FansSet{margin-top: 5px;}.FansSet a{background: #4DABFF;padding: 5px;color: #fff;}</style>
 * @package Deng 插件 for Spzac主题
 * @author 小灯泡设计
 * @version 1.0
 * @link https://www.dpaoz.com/
 */
class Deng_Plugin extends Widget_Abstract_Users implements Typecho_Plugin_Interface
{
    /**
     * 激活插件方法,如果激活失败,直接抛出异常
     * 
     * @access public
     * @return void
     * @throws Typecho_Plugin_Exception
     */
    public static function activate()
    {
      Typecho_Plugin::factory('Widget_Register')->register = array('Deng_Plugin', 'zhuce'); 
	  Typecho_Plugin::factory('Widget_Register')->finishRegister = array('Deng_Plugin', 'zhucewan');
      Typecho_Plugin::factory('Widget_Login')->loginSucceed = array('Deng_Plugin', 'Loginwan');
	 
      Typecho_Plugin::factory('admin/footer.php')->end = array('Deng_Plugin', 'footerjs');
 
	  //Typecho_Plugin::factory('Widget_Users_Profile')->filter = array('Deng_Plugin', 'usertip');
      //Typecho_Plugin::factory(' Widget_Users_Edit')->filter = array('Deng_Plugin', 'usertip');
      $index = Helper::addMenu('会员信息');
      Helper::addAction('Deng-post-free', 'Deng_Action');
      Helper::addPanel($index, 'Deng/html/profile.php', '会员信息', '管理会员信息', 'administrator');
      Helper::addPanel($index, 'Deng/html/posts.php', '付费会员', '管理付费会员', 'administrator');
      
      //找回密码
      Helper::addRoute('Deng_forgot', '/Deng/forgot', 'Deng_Widget', 'doForgot');
      Helper::addRoute('Deng_reset', '/Deng/reset', 'Deng_Widget', 'doReset');
      
      
      // 添加会员期限字段
      self::useretimesqlInstall();
      
      return _t('请配置此插件的SMTP信息, 以使您的插件生效');
	  
    }
    

    
    /**
     * 禁用插件方法,如果禁用失败,直接抛出异常
     * 
     * @static
     * @access public
     * @return void
     * @throws Typecho_Plugin_Exception
     */
    public static function deactivate(){
        
        Helper::removeRoute('Deng_reset');
        Helper::removeRoute('Deng_forgot');
        
        $index = Helper::removeMenu('会员信息');
        Helper::removeAction('Deng-post-free');
		Helper::removePanel($index, 'Deng/html/profile.php');
        Helper::removePanel($index, 'Deng/html/posts.php');
        return _t('插件已被禁用');
        
    }
    
    /**
     * 获取插件配置面板
     * 
     * @access public
     * @param Typecho_Widget_Helper_Form $form 配置面板
     * @return void
     */
    public static function config(Typecho_Widget_Helper_Form $form)
    {

    $yonghuzu = new Typecho_Widget_Helper_Form_Element_Radio('yonghuzu',array(
      'visitor' => _t('访问者'),
      'subscriber' => _t('关注者'),
      'contributor' => _t('贡献者'),
      'editor' => _t('编辑'),
      'administrator' => _t('管理员')
    ),'subscriber',_t('注册用户默认用户组设置'),_t('<p class="description">
不同的用户组拥有不同的权限，具体的权限分配表请<a href="http://docs.typecho.org/develop/acl" target="_blank" rel="noopener noreferrer">参考这里</a>.</p>'));
    $form->addInput($yonghuzu); 
    
    //拓展设置
    $tuozhan = new Typecho_Widget_Helper_Form_Element_Checkbox('tuozhan', 
    array('register-nb' => _t('勾选该选项后台注册功能将可以直接设置注册密码'),
),
    array(), _t('拓展设置'), _t('仅限程序后台页面有效'));
    $form->addInput($tuozhan->multiMode());
      
        //拓展设置
    $noato = new Typecho_Widget_Helper_Form_Element_Checkbox('noato', 
    array('pa-noato' => _t('访问默认登录注册页自动跳转主题注册登录页面'),
),
    array(), _t('页面权限'), _t('禁止访问默认登录注册页面'));
    $form->addInput($noato->multiMode());
    
    
    $iyuukey = new Typecho_Widget_Helper_Form_Element_Text('iyuukey', NULL, '', _t('爱语飞飞key'), _t(''));
    $form->addInput($iyuukey->multiMode());
   
    //密码找回
    
    $host = new Typecho_Widget_Helper_Form_Element_Text('host', NULL, '', _t('服务器(SMTP)'), _t('如: smtp.exmail.qq.com'));
        $port = new Typecho_Widget_Helper_Form_Element_Text('port', NULL, '465', _t('端口'), _t('如: 25、465(SSL)、587(SSL)'));

        $username = new Typecho_Widget_Helper_Form_Element_Text('username', NULL, '', _t('帐号'), _t('如: hello@example.com'));
        $password = new Typecho_Widget_Helper_Form_Element_Password('password', NULL, NULL, _t('密码'));

        $secure = new Typecho_Widget_Helper_Form_Element_Select('secure',array(
            'ssl' => _t('SSL'),
            'tls' => _t('TLS'),
            'none' => _t('无')
        ), 'ssl', _t('安全类型'));

        $form->addInput($host);
        $form->addInput($port);
        $form->addInput($username);
        $form->addInput($password);
        $form->addInput($secure);


      
      
//    $tcat = new Typecho_Widget_Helper_Form_Element_Text('tcat', NULL, NULL, _t('特例分类'), _t('在这里填入一个分类mid，分类间用英文的半角逗号隔开如【1,2】，这些分类贡献者发布文章必须需要经过审核！'));
//    $form->addInput($tcat);
    }
    
    /**
     * 个人用户的配置面板
     * 
     * @access public
     * @param Typecho_Widget_Helper_Form $form
     * @return void
     */
    public static function personalConfig(Typecho_Widget_Helper_Form $form){}
    
    /**
     * 插件实现方法
     * 
     * @access public
     * @return void
     */
  
// SQL创建
    // 添加个人会员期限字段
    public static function useretimesqlInstall()
    {
        $db = Typecho_Db::get(); 
        if (!array_key_exists('endtime', $db->fetchRow($db->select()->from('table.users')))) {
        $db->query('ALTER TABLE `'.$db->getPrefix().'users` ADD `endtime` INT(11) DEFAULT NULL;');         
        }
		
    }  
  
  
  
public static function zhuce($v) {
  /*获取插件设置*/
   $yonghuzu = Typecho_Widget::widget('Widget_Options')->plugin('Deng')->yonghuzu;
  $hasher = new PasswordHash(8, true);
  /*判断注册表单是否有密码*/
  if(isset(Typecho_Widget::widget('Widget_Register')->request->password)){
    /*将密码设定为用户输入的密码*/
    $generatedPassword = Typecho_Widget::widget('Widget_Register')->request->password;
  }else{
    /*用户没输入密码，随机密码*/
    $generatedPassword = Typecho_Common::randString(7);
  }
  /*将密码设置为常量，方便下个函数adu()直接获取*/
  define('passd', $generatedPassword);
  /*将密码加密*/
  $wPassword = $hasher->HashPassword($generatedPassword);
  /*设置用户密码*/
  $v['password']=$wPassword;
  /*将注册用户默认用户组改为插件设置的用户组*/
  $v['group']=$yonghuzu;
  /*返回注册参数*/
  return $v;
}
public static function zhucewan($obj) {
 /*获取密码*/
 $wPassword=passd;
 /*登录账号*/
 $obj->user->login($obj->request->name,$wPassword);
 /*删除cookie*/
 Typecho_Cookie::delete('__typecho_first_run');
 Typecho_Cookie::delete('__typecho_remember_name');
 Typecho_Cookie::delete('__typecho_remember_mail');
 /*发出提示*/
 $obj->widget('Widget_Notice')->set(_t('用户 <strong>%s</strong> 已经成功注册, 密码为 <strong>%s</strong>', $obj->screenName, $wPassword), 'success');
 /*跳转地址(后台)*/
 if (NULL != $obj->request->referer) {
 $obj->response->redirect($obj->request->referer);
 }else if(NULL != $obj->request->tz){
   if (Helper::options()->rewrite==0){$authorurl=Helper::options()->rootUrl.'/index.php/author/';}else{$authorurl=Helper::options()->rootUrl.'/author/';}
  $obj->response->redirect($authorurl.$obj->user->uid);
 }else{
 $obj->response->redirect($obj->options->adminUrl);
 }
}
  

public static function Loginwan($obj) {
    
 /*跳转地址(后台)*/
 if (NULL != $obj->request->referer) {
 $obj->response->redirect($obj->request->referer);
 }
 else{
 $obj->response->redirect($obj->options->adminUrl);
 }
 
 
}

 public static function footerjs(){
   if (!empty(Typecho_Widget::widget('Widget_Options')->plugin('Deng')->tuozhan) && in_array('register-nb',  Typecho_Widget::widget('Widget_Options')->plugin('Deng')->tuozhan)){
?>
<script>
var Denghtml='<p><label for="password" class="sr-only">密码</label><input type="password"  id="password" name="password" placeholder="输入密码" class="text-l w-100" autocomplete="off" required></p><p><label for="confirm" class="sr-only">确认密码</label><input type="password"  id="confirm" name="confirm" placeholder="再次输入密码" class="text-l w-100" autocomplete="off" required></p>';
$("#mail").parent().after(Denghtml);
</script>
<?php
   }
   
      if (!empty(Typecho_Widget::widget('Widget_Options')->plugin('Deng')->noato) && in_array('pa-noato',  Typecho_Widget::widget('Widget_Options')->plugin('Deng')->noato)){
?>
<script>
 if ($(".typecho-login").length > 0) {
   
     window.location.href = 'http://'+window.location.hostname;
 }
</script>
<?php
   }
   
   
   
 }
  
  
  
  
  public static function form($action = NULL)
	{
		/** 构建表格 */
		$options = Typecho_Widget::widget('Widget_Options');
		$form = new Typecho_Widget_Helper_Form(Typecho_Common::url('/action/Deng-post-free', $options->index),
		Typecho_Widget_Helper_Form::POST_METHOD);
		
		/** 昵称 */
		$screenName = new Typecho_Widget_Helper_Form_Element_Text('screenName', NULL, NULL, _t('昵称*'));
		$form->addInput($screenName);	

		
		/** 会员期限 */
		$endtime = new Typecho_Widget_Helper_Form_Element_Text('endtime', NULL, NULL, _t('会员期限*'));
		$form->addInput($endtime);
        
			
		/** 链接动作 */
		$do = new Typecho_Widget_Helper_Form_Element_Hidden('do');
		$form->addInput($do);
		
		/** 链接主键 */
		$uid = new Typecho_Widget_Helper_Form_Element_Hidden('uid');
		$form->addInput($uid);
		
		/** 提交按钮 */
		$submit = new Typecho_Widget_Helper_Form_Element_Submit();
		$submit->input->setAttribute('class', 'btn primary');
		$form->addItem($submit);
		$request = Typecho_Request::getInstance();

        if (isset($request->uid) && 'insert' != $action) {
            /** 更新模式 */
			$db = Typecho_Db::get();
			$prefix = $db->getPrefix();
            $post = $db->fetchRow($db->select()->from($prefix.'users')->where('uid = ?', $request->uid));
            if (!$post) {
                throw new Typecho_Widget_Exception(_t('用户不存在'), 404);
            }
            
            $screenName->value($post['screenName']);
            $endtime->value($post['endtime']);  
          
            if(!$post['endtime']){           
                $endtime->value(date('Y-m-d H:i:s',time()));
            }
            else{
             
             $etime= date('Y-m-d H:i:s',$post['endtime']);
              
              $endtime->value($etime); }
          
            $do->value('update');
            $uid->value($post['uid']);
            $submit->value(_t('确认修改'));
            $_action = 'update';
        } else {
            $submit->value(_t('确认修改'));
        }
        
        if (empty($action)) {
            $action = $_action;
        }
      
        return $form;
	}
  
  
  
  
  
  
  
  
  
  
  
  
  
}
