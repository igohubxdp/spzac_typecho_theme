<?php
include 'common.php';
include 'header.php';
include 'menu.php';


//调用最近登录时间
function get_last_login($userid){
    $now = time();
    $db     = Typecho_Db::get();
    $prefix = $db->getPrefix();
    $row = $db->fetchRow($db->select('activated')->from('table.users')->where('uid = ?', $userid));
    return Typecho_I18n::dateWord($row['activated'], $now);
}

//调用用户注册时间
function reg_login($userid){
    $now = time();
    $db     = Typecho_Db::get();
    $prefix = $db->getPrefix();
    $row = $db->fetchRow($db->select('created')->from('table.users')->where('uid = ?', $userid));
    $ti = Typecho_I18n::dateWord($row['created'], $now);
    $d1 = $row['created'];//过去的某天，你来设定
    $d2 = ceil((time()-$d1)/60/60/24);//现在的时间减去过去的时间，ceil()进一函数
    return $d2;
}
//调用用户会员期限
function end_time($userid){
   
    $db   = Typecho_Db::get();
    $prefix = $db->getPrefix();
    $row = $db->fetchRow($db->select('endtime')->from('table.users')->where('uid = ?', $userid));
    if($row['endtime']!=null){
    return  date('Y-m-d H:i:s',$row['endtime']);
    }
    else{
      return 'NULL';
    }
}


?>
<style type="text/css">
.am-fr {
    float: right;
    margin-top: -10px;
}
li.am-pagination-prev {
    float: left;
    margin: 0 10px;
    list-style: none;
}
li.am-pagination-next {
    float: left;
    margin: 0 10px;
    list-style: none;
}
</style>


<?php 
	$db = Typecho_Db::get();
	$queryGoods= $db->select()->from('table.users')->where('group = ?', "contributor")->order('uid',Typecho_Db::SORT_DESC)->limit(20); 
	$rowGoods = $db->fetchAll($queryGoods);
?>
<div class="main">
    <div class="body container">
        <?php include 'page-title.php'; ?>
        <div class="row typecho-page-main" role="main">
            <div class="col-mb-12 typecho-list">
            
                <div class="col-mb-12 col-tb-9" role="main"> 
                <form method="post" name="manage_posts" class="operate-form">
                <div class="typecho-table-wrap">
                    <table class="typecho-list-table">
                        <colgroup>
                            <col width="15%"/>
                            <col width="15%"/>
                            <col width="15%"/>
                            <col width="15%"/>
                            <col width="15%"/>
                            <col width="15%"/>
                        </colgroup>
                        <thead>
                            <tr>
                                <th><?php _e('昵称'); ?></th>
                                <th><?php _e('邮箱'); ?></th>
                                <th><?php _e('用户组'); ?></th>
                                <th><?php _e('注册天数'); ?></th>
                                <th><?php _e('近期登陆'); ?></th>
                                <th><?php _e('会员期限'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                        	<?php
							  foreach($rowGoods as $value){
							?>
                            <tr id="<?=$value["uid"];?>">
                                <td><a href="<?php echo $request->makeUriByRequest('uid='.$value["uid"]); ?>" title="点击编辑"><?php echo $value["screenName"]; ?></a>
                                <td><?php echo $value["mail"]; ?></td>
                                <td><?php echo $value["group"]; ?></td>
                              <td><?php echo reg_login($value["uid"]); ?>天</td>
                              <td><?php echo get_last_login($value["uid"]); ?></td>
                              <td><?php echo end_time($value["uid"]); ?></td>
                            </tr>
                            <?php
							  }
							?>
                        </tbody>
                    </table>
                </div>
                </form><!-- end .operate-form -->

                <div class="typecho-list-operate clearfix">
                    <div class="am-cf">
					  官网联系：https://www.dpaoz.com
					</div>
                </div><!-- end .typecho-list-operate -->
				
				</div>
                <div class="col-mb-12 col-tb-3" role="form">
                    <?php Deng_Plugin::form()->render(); ?>
                </div>
            </div><!-- end .typecho-list -->
        </div><!-- end .typecho-page-main -->
    </div>
</div>

<?php
include 'copyright.php';
?>
